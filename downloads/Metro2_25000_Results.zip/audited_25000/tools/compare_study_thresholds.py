"""Compare two full explorer exports from recorded native runs with different cure thresholds."""
import argparse
from collections import Counter
from hashlib import sha256
from itertools import zip_longest
import json
from pathlib import Path


def accounts(path, metadata):
    decoder = json.JSONDecoder()
    with path.open(encoding="utf-8") as stream:
        if stream.readline().strip() != 'window.METRO2_DATA={"accounts":[':
            raise ValueError(f"Expected a full export from build_explorer.py: {path}")
        for line in stream:
            row, end = decoder.raw_decode(line)
            yield row
            tail = line[end:].strip()
            if tail == ",":
                continue
            if not tail.startswith('],"meta":') or not tail.endswith("};") or stream.read().strip():
                raise ValueError(f"Invalid export trailer: {path}")
            metadata.update(json.loads(tail[len('],"meta":'):-2]))
            return
        raise ValueError(f"Missing metadata: {path}")


def add_digest(digest, values):
    digest.update(json.dumps(values, separators=(",", ":"), ensure_ascii=True).encode("ascii") + b"\n")


def confirm(cure, threshold):
    if cure is None:
        return None
    year, month = map(int, cure[:7].split("-"))
    y, m = divmod(12 * year + month - 1 + threshold - 1, 12)
    return f"{y:04}-{m + 1:02}-01"


def decision(row):
    cure = row["credit_cure_date"]
    return {"threshold":row["cure_consecutive_months_required"],"cure_start":cure,
            "confirmed_through":confirm(cure,row["cure_consecutive_months_required"]),
            "credit_through":row["credit_impact_end_date"],"treatment":row["remediation_treatment"],
            "cure_review":row["manual_review_flag"],"review_reason":row["manual_review_reason"],
            "monthly_edits":sum(m[1]!=m[2] for m in row["months"])}


def compare(first, second):
    metadata=[{},{}]
    hashes=[{k:sha256() for k in ("account_ids","source_account_fields","original_dated_months","incident_dates")} for _ in range(2)]
    outcomes=[Counter(),Counter()]
    thresholds=[set(),set()]
    changes=Counter()
    example=None
    example_priority=-1
    source_fields=("account","profile_type","latest_doai","date_closed","account_status_17a","payment_rating_17b",
                   "date_of_first_delinquency","full_php","php_left_byte_date","php_right_byte_date")
    for a,b in zip_longest(accounts(first,metadata[0]),accounts(second,metadata[1])):
        if a is None or b is None or a["account"]!=b["account"]:
            raise ValueError("Cohort size or ordered account IDs differ.")
        decisions=[]
        for i,row in enumerate((a,b)):
            account=row["account"]
            thresholds[i].add(row["cure_consecutive_months_required"])
            d=decision(row); decisions.append(d)
            h=hashes[i]
            add_digest(h["account_ids"],account)
            add_digest(h["source_account_fields"],[row[k] for k in source_fields])
            add_digest(h["incident_dates"],[account,row["impact_start_date"],row["impact_end_date"]])
            add_digest(h["original_dated_months"],[account,[[m[0],m[1]] for m in row["months"]]])
            totals=outcomes[i]
            totals["accounts"]+=1;totals["represented_months"]+=len(row["months"])
            totals["confirmed_cures"]+=int(d["cure_start"] is not None)
            totals["monthly_cure_reviews"]+=d["cure_review"];totals["monthly_edits"]+=d["monthly_edits"]
            totals["field_research"]+=int(row.get("account_field_review_reason") is not None)
            totals["explicit_dofd_clears"]+=int(row["clear_date_of_first_delinquency"])
            totals["accounts_with_monthly_edits"]+=int(d["monthly_edits"]>0)
            totals[d["treatment"]]+=1
        x,y=decisions
        for k in ("cure_start","confirmed_through","credit_through","treatment","cure_review","review_reason","monthly_edits"):
            changes[k]+=int(x[k]!=y[k])
        priority=3 if x["cure_review"]!=y["cure_review"] else 2 if x["credit_through"]!=y["credit_through"] else 1 if x["confirmed_through"]!=y["confirmed_through"] else 0
        if priority>example_priority:
            example={"account":a["account"],"bank_start":a["impact_start_date"],"bank_end":a["impact_end_date"],
                     "as_of":a["latest_doai"],"latest_original_month":a["php_left_byte_date"],
                     "original_history_newest_first":a["full_php"],"first":x,"second":y}
            example_priority=priority
    if not all(len(t)==1 for t in thresholds) or thresholds[0]==thresholds[1]:
        raise ValueError("Supply two cohorts with a different, uniform cure threshold.")
    if not all(m.get("module2Sha256") and m.get("configuredModule2Sha256") for m in metadata):
        raise ValueError("Use the verified run receipt when exporting each input.")
    for key in ("policyId","accountFieldPolicy","module2Sha256"):
        if metadata[0].get(key)!=metadata[1].get(key):
            raise ValueError(f"Source policy or engine differs: {key}")
    proof=[{k:h.hexdigest() for k,h in hs.items()} for hs in hashes]
    if proof[0]!=proof[1]:
        raise ValueError("Original account fields, dated monthly observations or incident dates differ.")
    identity=[{"database":m["database"],"cure_months":next(iter(t)),"module2_source_sha256":m["module2Sha256"],
               "module2_configured_sha256":m["configuredModule2Sha256"],"snapshot_utc":m["snapshotUTC"]}
              for m,t in zip(metadata,thresholds)]
    return {"pass":True,"studies":identity,"identical_input_sha256":proof[0],"first":dict(outcomes[0]),"second":dict(outcomes[1]),
            "accounts_changed_by_measure":dict(changes),"example":example if example_priority>0 else None}


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("baseline",type=Path);parser.add_argument("alternative",type=Path)
    parser.add_argument("--output",type=Path)
    opts=parser.parse_args()
    if opts.output and opts.output.resolve() in {p.resolve() for p in (opts.baseline,opts.alternative)}:
        parser.error("Use a separate file for the comparison.")
    result=json.dumps(compare(opts.baseline,opts.alternative),indent=2)+"\n"
    if opts.output:opts.output.write_text(result,encoding="utf-8")
    else:print(result,end="")

# Validation report · Metro 2 remediation sandbox

**The developer retest passed all 55 follow-up assertions. The independently reviewed release failed 42 of those 55.** Both releases passed the original 48 assertions. The new tests are what exposed an older processing cutoff, a changed bank-issue date and a delinquency date from a different episode. The independent auditor placed the reviewed release on hold. The corrected package awaits a new independent disposition and Andrew Goad’s publication decision. [Audit findings](#audit-findings) · [Population reconciliation](#population-reconciliation) · [Four dated cases](#four-dated-cases) · [Run the checks](#run-the-checks) · [Scope and sign-off](#scope-and-sign-off)

## What was tested

The question was whether a bank’s proposed correction follows the **original evidence available on the reporting date**. That includes preserving accurate history before the incident, extending the review after the bank’s end date, recognizing when cure becomes observable and making a supported decision about each current account field. Continued processing also has to protect the previous decision if incoming evidence is stale. [Business requirements](BUSINESS_REQUIREMENTS.md) · [Change log](CHANGELOG.md) · [Code audit](CODE_AUDIT.md)

The recorded databases ran PostgreSQL 16.2 on 64-bit Linux with PowerShell 7.7.0. The main 25,000-account database is `metro_episode_scoped_25000`. Its severe-event policy is `REVERSAL_AWARE_SEVERE_V2`. Its account-field policy is `EVIDENCE_SCOPED_FIELDS_V2`. The public Git baseline is `1201adcc0b3a74a0f81e8f456a9e3d901f0aaca7`. The independently re-audited private ZIP starts with `57390959d867` and used field policy V1. The prior independent audit covered ZIP `c946f81efe7a`. The prefixes below identify source files. The study receipt also records configured SQL hashes for the executed population and threshold. [Results and run receipts](docs/downloads/Metro2_25000_Results.zip) · [Developer retest evidence](docs/downloads/Metro2_Developer_Retest.json)

| Executed input | SHA-256 prefix |
| --- | --- |
| [Module 1 · generator](src/module_01_metro2_synthetic_portfolio_generator.sql) | `8a10a6310df2` |
| [Module 2 · remediation](src/module_02_metro2_remediation_engine.sql) | `1a1566dee12d` |
| [Independent SQL verifier](tools/verify_study.sql) | `64f699cb28eb` |
| [Account-field research query](tools/export_account_field_review.sql) | `16cad8b3b39a` |
| [Field 25 exception query](tools/export_field25_exceptions.sql) | `655ed6eb12fa` |

## Audit findings

The same 55 expectations ran on two isolated PostgreSQL instances. They comprise 27 field scenarios, 10 worklist checks, three corrupt-output challenges, 12 rejected input or rollback cases and three successful continuing-incident paths. The re-audited release passed 13. The corrected release passed 55. The first audit’s 48 checks also ran against both releases and both passed 48. The earlier 34 failures out of 48 belong to the first private audit target, `c946f81efe7a`. [Regression suite and comparison commands](tests/README.md) · [Finding walkthrough](docs/retest.html)

| Follow-up finding | Observed acceptance result |
| --- | --- |
| **Saved incident and processing cutoff.** Moving 17899’s incident start back one month could suppress its accurate December delinquency. Reapplying an April cutoff could reopen a case already cured at the May cutoff. [BR-03](BUSINESS_REQUIREMENTS.md#br-03) · [BR-11](BUSINESS_REQUIREMENTS.md#br-11) | Continuing-incident runs compare the saved windows and prior per-account cutoffs before replacement. Contradictory copies, invalid days and a backward cutoff were rejected with prior decisions intact. Equal cutoffs and advances succeeded. A separate 27-account bridge from the public schema preserved every incident, including one account that advanced alongside 25 unchanged snapshots and a same-cutoff source correction. |
| **Field basis and closure.** An old DOFD could be cleared after intervening current months, or across an original unknown month. An open-status proposal could disregard a reported closure date. [BR-07](BUSINESS_REQUIREMENTS.md#br-07) · [BR-08](BUSINESS_REQUIREMENTS.md#br-08) | To clear a supplied date, the original onset month must contain a numeric delinquency and the original adverse observations must continue through the corrected basis. An intervening current month separates episodes. An original `D` leaves continuity unproved. Contradictory closure timing keeps the source fields and refers them for servicing evidence. A corroborated pre-incident onset can still qualify when the episode continues through the affected month. |
| **Missing historically required 17B.** Status 13 with a missing rating left the conditional Field 25 decision unresolved. [BR-08](BUSINESS_REQUIREMENTS.md#br-08) · [BR-10](BUSINESS_REQUIREMENTS.md#br-10) | Retained records with a missing applicable rating enter servicing research even without a PHP change. With status 13 and unknown rating, obtain the rating to decide the historical date condition. Status 65 requires a date independently of rating. An absent date at 65 can therefore appear on both worklists. The controls covered all seven statuses in the historical screen, including legacy 05 and whitespace-only input. |
| **Export integrity.** A fabricated deletion, invented onset, omitted clear or unsupported field change could appear in a reader’s copy. [BR-11](BUSINESS_REQUIREMENTS.md#br-11) · [BR-12](BUSINESS_REQUIREMENTS.md#br-12) | The current-policy converter reconstructs treatment, history changes, field eligibility and servicing research from original observations. Contradictory rows fail before the destination is replaced. Both the SELECT-only database path and the DBeaver CSV path are covered. An existing validated file survives failure. Older policy versions retain their source identity and narrower validation scope. [Export guide](tools/README.md) |

A separately expressed SQL verifier passed all **22 controlled accounts and 91 account-months** against literal expected field outcomes. It detected all **13 deliberate mutations**, including a falsely cleared earlier episode, omitted required-rating research and an invalid incident day copied into three tables. It passed standalone and inside the launcher’s read-only snapshot. A separate native engine comparison covered 37 cases, with 25 changed dispositions and 12 preserved outcomes. These sets overlap in subject matter and have separate denominators. In the results ZIP, the current receipts are `checks/followup/before-after.json`, `checks/followup/independent-verifier.json`, `checks/followup/engine-challenges.json` and `checks/followup/public-bridge.json`. [Independent verifier](tools/verify_study.sql) · [Developer evidence](docs/downloads/Metro2_Developer_Retest.json)

The original audit checks remain part of the record. They cover unrelated post-cure fields, closed 61–65 and 13 with a later adverse episode, future-dated history, unsupported source marks, the 187-account reader copy, handoff deep links and historical 17B applicability. The earlier 14-account verifier suite covered 78 original months and 12 mutations. Its receipt describes the prior test generation. [Original controls and fixtures](tests/README.md) · [Code history](CHANGELOG.md)

## Population reconciliation

A cohort and account ID identify a case. A cure can be observed even when no correction was proposed. The data below come from separate native runs. Each used three original current months after the bank issue unless shown otherwise. [Study results](docs/downloads/Metro2_25000_Results.zip)

| Accounts / cure months | Original months | No impact | Simple cleanup | Full cleanup | Delete | Edited months | Cures | Monthly reviews | Date clears | Date exceptions | Field research |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 / 3 | 28 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| 500 / 3 | 17,596 | 405 | 86 | 2 | 7 | 212 | 290 | 67 | 47 | 3 | 1 |
| 1,000 / 3 | 35,395 | 803 | 172 | 3 | 22 | 461 | 555 | 133 | 100 | 3 | 0 |
| 1,000 / 4 | 35,395 | 789 | 185 | 3 | 23 | 496 | 494 | 147 | 109 | 3 | 0 |
| 25,000 / 3 | 873,193 | 20,506 | 3,904 | 124 | 466 | 11,071 | 14,350 | 3,048 | 2,340 | 130 | 26 |

**Threshold sensitivity.** Requiring four consecutive current months in the same 1,000-account study lowered observed cures from 555 to 494. Fourteen additional accounts entered monthly review, and 35 additional monthly entries changed. Both runs used the same 35,395 original observations and account-level bank dates. Account 57 illustrates the decision. Its issue ran from May 2024 through June 2025. At the October 1, 2025 cutoff, original July, August and September were all current. With three required, July starts cure, September confirms it and credit impact ends in June. With four required, cure remains open and the review extends through September. Both runs propose one monthly change for this account. Reproduce the comparison by setting `-CureMonths 3` and `-CureMonths 4` on separate fresh study runs. [Run and compare a study](docs/run.html) · [Paired threshold receipt](docs/downloads/Metro2_Threshold_Comparison_1000.json)

**All 25,000 DOFD decisions.** Of 24,534 retained accounts, 2,434 kept a populated original date, 19,760 retained an empty date and 2,340 explicitly cleared a supplied date. No replacement date was set. The other 466 accounts received proposed tradeline deletion. All 2,340 clears had an observed numeric source onset and uninterrupted original adverse months through the corrected basis. All had an open source classification and a proposed status of 11. Of those dates, 329 came before the bank issue, 1,160 during it and 851 after the issue ended. The corresponding pre-incident delinquency stayed visible on all 329. The favorable current-field election and the monthly history correction are distinct actions. [Account 17899](docs/scale/index.html#account=17899) · [Results](docs/downloads/Metro2_25000_Results.zip)

**Three worklists.** The monthly handoff has 3,048 rows, including 2,058 with insufficient follow-up and 990 open accounts without observed cure. The known Field 25 date exceptions total 130, with status counts 61 (12), 62 (35), 63 (13), 64 (66), 65 (3) and 97 (1). None were on the monthly queue. The separate field-research file has 26 missing historically required ratings, comprising 65 (3), 94 (9) and 95 (14). The three status-65 accounts appear on both source worklists. The other 23 have dates. The earlier release produced zero field-research rows on the same cohort. None of the 26 are on the monthly queue. Comparing the two 25,000-account runs, all 873,193 original/proposed monthly tuples and every effective 17A, 17B, DOFD and clear action matched. Apart from the policy version, the 26 new servicing reasons were the only changed account fields. [Monthly workbook](docs/downloads/Metro2_Manual_Review_25000.xlsx) · [Monthly CSV](docs/downloads/Metro2_Manual_Review_25000.csv) · [Missing dates](docs/downloads/Metro2_Field25_Source_Exceptions_25000.csv) · [Field research](docs/downloads/Metro2_Account_Field_Review_25000.csv)

The workbook check compares 73,152 source cells and 6,096 original/proposed rating-applicability notes in the 25,000-account handoff. Module 2’s ordered samples show the first 100 of 2,806 status changes, 4,028 PHP changes and 2,340 DOFD changes respectively. Account 17899 ranks 134th in the date sample query and is available in the full export. [QA definitions and readback](CODE_AUDIT.md) · [Results](docs/downloads/Metro2_25000_Results.zip)

## Four dated cases

The case checker reconstructs the dates and decisions from original monthly history. Bank and credit windows below are inclusive. The date of account information (DOAI) is one month after the newest payment history profile (PHP) month. Cure requires the first three consecutive **original** current months after bank impact ends. The first is its effective start. The third supplies confirmation when the next reporting cycle arrives. [BR-03 through BR-06](BUSINESS_REQUIREMENTS.md#br-03) · [BR-09](BUSINESS_REQUIREMENTS.md#br-09) · [Case checker](tests/verify_featured_cases.py)

| Account and cohort | Bank issue → credit impact through | Cure evidence and observed decision |
| --- | --- | --- |
| [24064 · 25,000](docs/scale/index.html#account=24064) | Dec 2023–Jan 2024 → Apr 2024 | May 1 DOAI. Five adverse months changed, three after the issue. November’s pre-issue `1` remained. Status 84 → 11 explicitly cleared the November source date. No cure start or confirmation. May history is due on the June 1 record. |
| [175 · 1,000](docs/index.html#account=175) | Apr 2024–Mar 2025 → Apr 2025 | Three months changed, including April after issue end. Original May–July zeros establish a May start and July confirmation, first observable August 1. The October 1 record is closed to monthly cure review. |
| [327 · 1,000](docs/index.html#account=327) | Dec 2024–Jan 2025 → Sep 2025 | March charge-off `L` fell in the extension. April `5` supplied a modeled reversal. Nine months changed, seven after issue end. September was the first original current month. October 1 had one of three, so review stayed open. |
| [17899 · 25,000](docs/scale/index.html#account=17899) | Jan 2025 → Jan 2025 | February 1 DOAI. January’s newest byte changed from `1` to `D`. December’s second byte stayed `1`. The proposal moved 71 → 11 and explicitly cleared the December date. No post-issue observation existed. February history first arrives March 1. |

The later February–April sequences for 17899 in H1 and H3 are **controlled continuations**, separate from its observed February 1 record. For an unresolved severe event ending in deletion, [account 987 in the 1,000-account study](docs/index.html#account=987) supplies the comparison. The four checked account histories, edits, cutoff dates and dispositions are in `checks/featured-cases.json` in the [results ZIP](docs/downloads/Metro2_25000_Results.zip).

## Run the checks

Use a PostgreSQL 15+ test server and its `psql` client. The PowerShell launcher creates a fresh database and a results folder. The Python regression runner creates and removes its own disposable databases. From a checkout or extracted study kit containing `src`, `tools` and `tests`, run the following in Windows PowerShell. Supply the appropriate test host, port and login. [Study walkthrough](docs/run.html) · [Launcher options and authentication](tools/RUN_STUDY.md) · [Regression instructions](tests/README.md)

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\tools\Run-Metro2Study.ps1 -AccountCount 25000
py -3 .\tests\run_regression.py --host localhost --port 5432 --user postgres --prompt-password --rolling-evidence .\rolling-snapshots.json --audit-evidence .\counterexamples.json --followup-evidence .\followup.json
```

Compare the run’s `totals.csv`, `outcomes.csv`, `policy_audit.json` and three worklists with the recorded results. `module2.log` contains the SQL readouts. From a checkout containing both Pages datasets, run the featured-case check separately. [PowerShell kit](docs/downloads/Metro2_PowerShell_Study.zip) · [Read-only DBeaver export instructions](tools/README.md)

```powershell
py -3 .\tests\verify_featured_cases.py --output .\featured-cases.json
```

## Scope and sign-off

The study uses synthetic observations. The next original numeric month after a severe event is a reversal proxy. Servicing records establish actual reversal, causation, closure and delinquency onset. Actual bureau submission, acknowledgment, subsequent reporting and the resulting consumer file require independent evidence. The largest native run covered 25,000 accounts. Windows PowerShell 5.1 compatibility was reviewed in source. The recorded runs used PowerShell 7.7.0 on Linux. A single database snapshot cannot authenticate concurrent changes to every saved copy of a valid incident date. Compare a retained authoritative source when available. [Operational responsibilities](BUSINESS_REQUIREMENTS.md#br-13)

CDIA is the official source. The public 2020 Credit Reporting Resource Guide, printed pp. 4-10, 4-11, 4-15 and 4-16, supports the historical field examples. The current 2026 field pages require authorized access and were outside this validation. The model lacks consumer bankruptcy or receivership indicators and their associated dates. A missing required rating at 05 or 13 can leave the historical date condition unresolved. The current authorized guide and applicable source records govern an actual submission. [CDIA Metro 2 resources](https://www.cdiaonline.org/resources/furnishers-of-data-overview/metro2-information/) · [2020 field definitions](https://autodealerplus.com/dealerzone/metro2.pdf#page=64) · [Historical Field 25 hierarchy](https://autodealerplus.com/dealerzone/metro2.pdf#page=70)

**Independent re-review remains open.** The 55-assertion comparison and fresh native receipts record developer acceptance of the corrections. The re-auditor’s hold applies to the identified prior package. Andrew Goad retains the publication decision. [Retest walkthrough](docs/retest.html) · [Audit handoff](AUDIT_PROMPT.md)

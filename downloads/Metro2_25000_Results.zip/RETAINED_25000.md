# Where the numbers came from

The root run.json, totals.csv, outcomes.csv, three worklists, Excel workbook and policy_audit.json are the original files for the independently audited **25,000-account, three-month** study. The current release reuses that snapshot. It did not execute the current engine on 25,000 accounts. Its 873,193 original months, 3,048 monthly cure reviews, 2,340 internal Field 25 clears, 26 servicing referrals and 130 missing-date cases retain their actual source identity.

| Evidence | Which source produced it |
| --- | --- |
| Root 25,000-account results and original checks | The auditor's input ZIP SHA-256 was a1c3b077f0e3164f9c23078b13b9a0f8c20da1891fa8b9bea251b859cabc14e7. Its executed Module 2 SHA-256 was 1a1566dee12d142ca5da080ed0db4ac600822e0216c9e24544212f200e343090. The archived source, original documentation, and earlier matched 1,000-account studies are in audited_25000/. |
| Current 1,000-account three- and four-month runs | cohorts/1000/ and cohorts/1000-cure4/ include the true native receipts, configured SQL and worklists. The current template hash is recorded in each run.json; their configured hashes differ only because the thresholds differ. checks/runtime/matched-native-cohorts.json reconciles every previously represented account and month. |
| Current 187-account, four-month quickstart | cohorts/187-cure4/ contains the new study's receipt and native outputs; checks/runtime/quickstart-187.json records its local viewer population and export digest. |
| Current code and release validation | src/, tools/, tests/, and the repository documents at root describe the current release. Use checks/runtime/ for the current receipt-backed comparison, the two dates-and-threshold cases and the new reuse controls. Original 25,000-account comparisons remain elsewhere in checks/. |

The archived results ZIP was 69d3b1b2fd985337a7c8e912fcb1f116eee312e968485038542535c14764633a. The earlier 57390959… and c946f81e… reviews and the spring public modules are distinct entries in source_lineage.json.

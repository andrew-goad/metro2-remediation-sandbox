"""Verify account and field deltas against the original monthly inputs and expected treatments."""
from collections import Counter
from datetime import date
import hashlib
import json
from pathlib import Path
import sys

open_status = dict(zip('0123456GHJKL', ('11','71','78','80','82','83','84','93','94','95','96','97')))
closed_basis = {'61':'J','62':'G','63':'K','64':'L','65':'H'}
expected_keys = ('remediated_full_php','remediated_account_status_17a','remediated_payment_rating_17b','remediated_date_of_first_delinquency','remediation_fields_modified','remediation_applied_flag','clear_account_status_17a','clear_payment_rating_17b','clear_date_of_first_delinquency')

def check(fields):
    original=fields['full_php']; months=sorted(fields['months'], reverse=True)
    bank_end=fields['impact_end_date']; bank_start=fields['impact_start_date']; threshold=fields['cure_consecutive_months_required']
    chron=list(reversed(months)); post=[m for m in chron if m[0]>bank_end]
    streak=0; cure=None; confirmation=None
    for index, (_,code,_,_) in enumerate(post):
        streak=streak+1 if code=='0' else 0
        if streak==threshold:
            cure=post[index+1-threshold][0]; confirmation=post[index][0]; break
    # Original dates rather than the SQL windows determine the proposed marks.
    eligible = [m for m in chron if m[0]>=bank_start and (not cure or m[0]<cure)]
    adverse = [m for m in eligible if m[1] in 'GHJKL']
    reversal_dates = [m[0] for m in chron if adverse and m[0]>adverse[-1][0] and (confirmation is None or m[0]<=confirmation) and m[1] in '0123456']
    recovery = bool(reversal_dates)
    assert fields['last_severe_month'] == (adverse[-1][0] if adverse else None)
    assert fields['severe_reversal_month'] == (reversal_dates[0] if reversal_dates else None)
    deletion = bool(adverse and not recovery)
    cleanup = bool(not deletion and (adverse or any(m[1] in '123456' for m in eligible)))
    changes={m[0] for m in eligible if cleanup and m[1] in '123456GHJKL'}
    after=''.join('D' if m[0] in changes else m[1] for m in months)
    assert original==''.join(m[1] for m in months)
    assert all(m[2]==a for m,a in zip(months,after))
    # Establish which source account field basis the actual proposed edits removed.
    was=fields['account_status_17a'];orig_rating=fields['payment_rating_17b']
    orig_dofd=fields['date_of_first_delinquency'];closed=fields['date_closed']
    cutoff=fields['latest_doai'];latest_date,latest_mark=months[0][:2]
    selected=lambda m:m[0] in changes
    adverse_marks=set('123456GHJKL')
    retained=[m[0] for m in months if m[1] in adverse_marks and not selected(m)]
    unknown=[m[0] for m in months if m[1]=='D']
    onset=(orig_dofd[:7]+'-01') if orig_dofd else None
    preclosure=None
    if closed:
        from datetime import timedelta
        previous=date.fromisoformat(closed).replace(day=1)-timedelta(days=1)
        preclosure=previous.replace(day=1).isoformat()
    rating_basis=next((m for m in months if m[0]==preclosure),None)
    closure_promoted=bool(closed and closed<=cutoff and orig_rating in set('123456GL') and rating_basis
                    and rating_basis[1]==orig_rating and selected(rating_basis)
                    and not any(period>preclosure for period in retained)
                    and (not onset or onset<=preclosure))
    major=closed_basis.get(was); deleted_events=[m[0] for m in months if major and m[1]==major and selected(m)]
    elected=None
    if cleanup:
        if (deleted_events and closed and max(deleted_events)<=closed<=cutoff
            and not any(m[1]==major and not selected(m) for m in months)
            and not any(period>max(deleted_events) for period in retained+unknown)
            and (not onset or onset<=max(deleted_events))
            and (orig_rating in (None,'0',major) or closure_promoted)):
            elected='13'
        elif was=='13' and closure_promoted:elected='13'
        elif (latest_date in changes and was==open_status.get(latest_mark)
            and orig_rating in (None,'0',latest_mark) and (not onset or onset<=latest_date)):
            elected='11'
    if elected is not None:
        anchor=(max(deleted_events) if major else preclosure) if elected=='13' else latest_date
        if closed and ((was!='13' and not major) or closed>cutoff
                       or any(m[1] in adverse_marks and m[0]>=closed[:7]+'-01' for m in months)):
            elected=None
        if onset and elected is not None:
            required_endpoints={anchor}
            if major and orig_rating not in (None,'0',major):required_endpoints.add(preclosure)
            onset_record=next((m for m in months if m[0]==onset),None)
            for endpoint in required_endpoints:
                if (not endpoint or endpoint<onset or not onset_record or onset_record[1] not in '123456'
                    or any(m[1] in '0DB' for m in months if onset<=m[0]<=endpoint)):
                    elected=None
                    break
    proposed_status='DA' if deletion else elected
    # Sparse overrides: absent election preserves original values. Only an evidence-backed
    # favorable field decision removes an existing adverse date. Dataset has no replacement dates.
    delta=[after if after!=original else None,proposed_status if proposed_status!=was else None,
            '0' if elected and orig_rating!='0' else None,None]
    clears=[False,False,bool(elected and orig_dofd is not None)]
    php,st,aux=delta[0] is not None,delta[1] is not None or clears[0],any(v is not None for v in delta[2:]) or any(clears[1:])
    names={(False,False,False):'NONE',(True,False,False):'PHP_ONLY',(False,True,False):'STATUS_ONLY',
        (True,True,False):'PHP_AND_STATUS',(True,False,True):'PHP_AND_DERIVED_FIELDS',
        (False,True,True):'STATUS_AND_DERIVED_FIELDS',(True,True,True):'PHP_STATUS_AND_DERIVED_FIELDS'}
    expect=(*delta,names.get((php,st,aux),'DERIVED_FIELDS_ONLY'),int(any((php,st,aux))),*clears)
    mismatches=[name for name,want in zip(expected_keys,expect) if fields[name]!=want]
    return mismatches, clears[2], clears[1]

def read_accounts(path):
    # The full release data is one JSON object, with each account on its own line.
    decoder=json.JSONDecoder()
    with path.open() as f:
        header=f.readline().strip()
        assert header=='window.METRO2_DATA={"accounts":['
        for line in f:
            row,_=decoder.raw_decode(line.lstrip()); yield row

if __name__=='__main__':
    path=Path(sys.argv[1]); failures=[]; counts=Counter()
    for r in read_accounts(path):
        mismatches,dofd,rating=check(r)
        counts['accounts']+=1;counts['months']+=len(r['months'])
        counts['explicit_dofd_clears_required']+=dofd
        counts['explicit_rating_clears_required']+=rating
        if mismatches: failures.append([r['account'],mismatches])
    result={'pass':not failures,'independent_python_check':'original-status policy -> monthly corrections -> 17A, 17B, DOFD nullable deltas / original / fields modified / applied flag',
       'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'counts':counts,'mismatches':len(failures),'first_failures':failures[:5]}
    Path(sys.argv[2]).write_text(json.dumps(result, indent=2)+'\n')
    print(result);sys.exit(1 if failures else 0)

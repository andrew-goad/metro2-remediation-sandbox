"""Exercise historical-required, blank, deletion and legacy-unknown rating notes on the native workbook writer."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import openpyxl

def control(writer, executable, source):
    with source.open(newline='',encoding='utf-8-sig') as f:
        reader=csv.DictReader(f); base=next(reader); columns=reader.fieldnames
    expected=[]
    for status in ('05','13','65','88','89','94','95'):
        expected.append((status,'','Required: modeled rating missing',status,'1','Required: verify rating from source'))
    for status in ('11','71','84','97'):
        expected.append((status,'1','Blank for this status',status,'','Blank for this status'))
    expected += [('DA','','Whole-account deletion instruction','DF','','Whole-account deletion instruction'),
                 ('','','Unknown: verify source status','','','Unknown: verify source status')]
    with tempfile.TemporaryDirectory() as temporary:
        d=Path(temporary)
        with (d/'sample.csv').open('w',newline='',encoding='utf-8') as s:
            form=csv.DictWriter(s,columns);form.writeheader()
            for i,(before,orig,_,after,new,_) in enumerate(expected,1):
                form.writerow(dict(base,account=str(i), original_status_17a=before,original_payment_rating_17b=orig,
                    proposed_effective_status_17a=after,proposed_effective_rating_17b=new,
                    internal_fields_to_clear='UNAVAILABLE_IN_SOURCE' if not before else ''))
        subprocess.run([executable,'-NoProfile','-NonInteractive','-File',str(writer),'-CsvPath',str(d/'sample.csv'),'-OutputPath',str(d/'sample.xlsx')],check=True)
        w=openpyxl.load_workbook(d/'sample.xlsx')
        for i,(_,orig,rule1,_,new,rule2) in enumerate(expected,2):
            assert (w.active[f'T{i}'].value,w.active[f'U{i}'].value,w.active[f'X{i}'].value,w.active[f'Y{i}'].value)==(orig or None,rule1,new or None,rule2)
    return {'pass':True,'controlled_rows':len(expected),'paired_status_applicability_notes':2*len(expected),'writer_sha256':hashlib.sha256(writer.read_bytes()).hexdigest(),
        'cases':[dict(original_status=o,modeled_original=r,original_standard_note=a,proposed_status=n,modeled_proposed=v,proposed_standard_note=b) for o,r,a,n,v,b in expected]}
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('writer',type=Path);p.add_argument('source',type=Path);p.add_argument('output',type=Path);p.add_argument('--powershell',default='pwsh')
    a=p.parse_args();a.output.write_text(json.dumps(control(a.writer,a.powershell,a.source),indent=2)+'\n')

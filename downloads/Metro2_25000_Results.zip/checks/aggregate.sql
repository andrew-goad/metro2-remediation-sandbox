WITH span AS (
    SELECT d.account, count(*) AS n_months, count(*) FILTER (WHERE d.original_status IS DISTINCT FROM d.remediated_status) AS n_changed,
           min(d.byte_date) FILTER (WHERE d.original_status='L') AS first_l,
           bool_or(d.original_status='L' AND d.byte_date BETWEEN f.impact_start_date AND f.impact_end_date) AS has_l_bank,
           bool_or(d.original_status='L' AND d.byte_date>f.impact_end_date AND d.is_within_credit_impact_window=1) AS has_l_tail
    FROM module2.metro2_remediation_php_detail d
    JOIN module2.metro2_remediation_final f USING(account) GROUP BY d.account
), a AS (
    SELECT f.*,s.n_months,s.n_changed,s.first_l,s.has_l_bank,s.has_l_tail,
           e.has_derog_in_credit_window,e.has_post_derog_recovery_evidence,
           CASE WHEN s.has_l_bank AND s.has_l_tail THEN 'bank_and_post_bank'
                WHEN s.has_l_bank THEN 'bank_only'
                WHEN s.has_l_tail THEN 'post_bank_only'
                ELSE 'no_chargeoff_mark_in_credit_window' END AS mark_period,
           CASE WHEN s.first_l IS NULL THEN 'no_chargeoff_in_history'
                WHEN s.first_l<f.impact_start_date THEN 'before_bank_issue'
                WHEN s.first_l<=f.impact_end_date THEN 'during_bank_issue'
                WHEN s.first_l<=f.credit_impact_end_date THEN 'extended_credit_window'
                ELSE 'after_credit_window' END AS first_l_period
    FROM module2.metro2_remediation_final f JOIN span s USING(account)
    JOIN module2.metro2_remediation_window_eval e USING(account)
), routes AS (
    SELECT remediation_treatment AS treatment, count(*) AS accounts,
           count(*) FILTER (WHERE manual_review_flag=0) AS without_review,
           count(*) FILTER (WHERE manual_review_reason='INSUFFICIENT_POST_IMPACT_HISTORY') AS insufficient_history,
           count(*) FILTER (WHERE manual_review_reason='NO_CURE_OPEN_ACCOUNT') AS no_cure_open,
           count(*) FILTER (WHERE credit_cure_date IS NOT NULL) AS cure_observed,
           count(*) FILTER (WHERE n_changed>0) AS accounts_with_changed_months,
           sum(n_changed) AS changed_months
    FROM a GROUP BY remediation_treatment ORDER BY remediation_treatment
), first_marks AS (
    SELECT first_l_period,remediation_treatment AS treatment,count(*) AS accounts
    FROM a GROUP BY first_l_period,remediation_treatment ORDER BY first_l_period,remediation_treatment
), all_marks AS (
    SELECT mark_period,remediation_treatment AS treatment,count(*) AS accounts
    FROM a GROUP BY mark_period,remediation_treatment ORDER BY mark_period,remediation_treatment
), recovery AS (
    SELECT profile_type,remediation_treatment AS treatment,has_post_derog_recovery_evidence AS later_numeric_mark,
           count(*) AS accounts,count(*) FILTER (WHERE credit_cure_date IS NOT NULL) AS observed_cure,
           count(*) FILTER (WHERE manual_review_flag=1) AS reviewed,
           count(*) FILTER (WHERE has_l_bank) AS with_chargeoff_in_bank_months,
           count(*) FILTER (WHERE first_l_period='during_bank_issue') AS with_first_chargeoff_in_bank_months,
           count(*) FILTER (WHERE first_l_period='extended_credit_window') AS with_first_chargeoff_after_bank_end
    FROM a WHERE has_derog_in_credit_window=1 GROUP BY 1,2,3 ORDER BY 1,2,3
), totals AS (
    SELECT count(*) AS accounts,sum(n_months) AS sum_represented_months,
           count(*) FILTER (WHERE n_changed>0) AS accounts_with_month_changes,
           sum(n_changed) AS changed_months,sum(manual_review_flag) AS reviewed,
           count(*) FILTER (WHERE remediation_applied_flag=1) AS with_treatment,
           count(*) FILTER (WHERE credit_cure_date IS NOT NULL) AS observed_cure,
           count(*) FILTER (WHERE credit_impact_end_date>impact_end_date) AS modeled_credit_window_extended,
           count(*) FILTER (WHERE has_derog_in_credit_window=1) AS major_derog_in_window,
           count(*) FILTER (WHERE has_derog_in_credit_window=1 AND has_post_derog_recovery_evidence=1) AS later_recovery_after_major_derog
    FROM a
)
SELECT jsonb_build_object('database',current_database(),'version',version(),'totals',(SELECT to_jsonb(totals) FROM totals),
                          'treatments',(SELECT jsonb_agg(to_jsonb(routes)) FROM routes),
                          'chargeoff_first_observed_position',(SELECT jsonb_agg(to_jsonb(first_marks)) FROM first_marks),
                          'chargeoff_any_month_inside_model_window',(SELECT jsonb_agg(to_jsonb(all_marks)) FROM all_marks),
                          'major_derog_cases',(SELECT jsonb_agg(to_jsonb(recovery)) FROM recovery));

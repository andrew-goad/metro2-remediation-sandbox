"""Compare the independently audited and successor full exports, worklists and QA samples."""
from collections import Counter
import csv
import hashlib
from itertools import zip_longest
import json
from pathlib import Path
import sys
from compare_cohorts import records

def sha(b):return hashlib.sha256(b).hexdigest()
def csvrows(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def effective(r,k):
    return None if r['clear_'+k] else (r['remediated_'+k] if r['remediated_'+k] is not None else r[k])
def qa_ids(log,header):
    lines=log.splitlines()
    i=next(i for i,l in enumerate(lines) if header in l)+2
    ids=[]
    while i<len(lines) and '|' in lines[i]:
        ids.append(int(lines[i].split('|',1)[0].strip()));i+=1
    return ids
def compare(old,new):
    count=months=0;field_counts=Counter();reason_counts=Counter();missing_model=Counter();dofd_actions=Counter()
    policy_pairs=Counter(); action_changes=[]; preissue_rows=[]; cleared_ids=[]; previous_clears=set()
    differences=[];reason_rows={}; ordered_ids={k:[] for k in ('status','php','dofd')};source_date_position=Counter()
    for a,b in zip_longest(records(old/'full.js'),records(new/'full.js')):
        assert a is not None and b is not None and a['account']==b['account']
        newcols=set(b)-set(a);assert not set(a)-set(b)
        assert a['account_field_policy']=='EVIDENCE_SCOPED_FIELDS_V1' and b['account_field_policy']=='EVIDENCE_SCOPED_FIELDS_V2'
        policy_pairs[b['account_field_policy']]+=1
        assert a['months']==b['months']
        assert all(a[k]==b[k] for k in ('remediation_treatment','manual_review_flag','manual_review_reason','impact_start_date','impact_end_date','credit_cure_date','full_php','latest_doai','last_severe_month','severe_reversal_month'))
        diffs=[k for k in a if k!='account_field_policy' and a[k]!=b[k]]
        if a['clear_date_of_first_delinquency']:previous_clears.add(a['account'])
        if b['clear_date_of_first_delinquency']:cleared_ids.append(b['account'])
        key_fields=('account_status_17a','payment_rating_17b','date_of_first_delinquency')
        acts=[k for k in key_fields if effective(a,k)!=effective(b,k) or a['clear_'+k]!=b['clear_'+k]]
        if acts:action_changes.append({'account':b['account'],'fields':acts})
        if a['clear_date_of_first_delinquency'] and a['date_of_first_delinquency']<a['impact_start_date']:
            start=a['date_of_first_delinquency'][:7]+'-01'
            episode=[m for m in a['months'] if m[0]>=start]
            preissue_rows.append({'account':b['account'],'source_onset':a['date_of_first_delinquency'],
                'incident_start':b['impact_start_date'],'latest_original_month':b['php_left_byte_date'],
                'source_onset_represented':any(m[0]==start for m in episode),
                'original_current_or_unknown_observed':any(m[1] in '0DB' for m in episode),
                'source_mark_at_onset':next((m[1] for m in episode if m[0]==start),None),
                'kept_clear':b['clear_date_of_first_delinquency'],'successor_research_reason':b['account_field_review_reason']})
        if diffs:
            differences.append({'account':b['account'],'differences':{k:[a[k],b[k]] for k in diffs}})
            field_counts.update(diffs)
        count+=1;months+=len(b['months'])
        reason=b['account_field_review_reason']
        if reason:
            reason_rows[str(b['account'])]=reason;reason_counts[reason]+=1
        if b['remediation_treatment']=='TRADELINE_DELETION':
            dofd_actions['tradeline_deletion']+=1
        else:
            source_dofd=b['date_of_first_delinquency'];result_date=effective(b,'date_of_first_delinquency')
            status=effective(b,'account_status_17a');rating=effective(b,'payment_rating_17b')
            if status in ('05','13','65','88','89','94','95') and not rating:missing_model[status]+=1
            if b['clear_date_of_first_delinquency']:
                dofd_actions['explicit_clear']+=1
                if source_dofd < b['impact_start_date']:source_date_position['before_incident']+=1
                elif source_dofd <= b['impact_end_date']:source_date_position['during_incident']+=1
                else:source_date_position['after_incident']+=1
            elif b['remediated_date_of_first_delinquency']:dofd_actions['set_or_replaced']+=1
            elif result_date:dofd_actions['retain_populated']+=1
            else:dofd_actions['retain_empty']+=1
        if b['remediated_account_status_17a'] or b['clear_account_status_17a']:ordered_ids['status'].append(b['account'])
        if b['remediated_full_php']:ordered_ids['php'].append(b['account'])
        if b['remediated_date_of_first_delinquency'] or b['clear_date_of_first_delinquency']:ordered_ids['dofd'].append(b['account'])
    csv_diffs={}
    for name in ('manual_review_handoff.csv','account_field_review.csv','field25_source_exceptions.csv','outcomes.csv'):
        aa=(old/name).read_bytes();bb=(new/name).read_bytes()
        csv_diffs[name]={'identical_bytes':aa==bb,'old_sha256':sha(aa),'new_sha256':sha(bb),'rows':len(csvrows(new/name))}
    reviews=csvrows(new/'account_field_review.csv');assert {r['account']:r['account_field_review_reason'] for r in reviews}==reason_rows
    assert len(reviews)==len(reason_rows)
    assert len(reason_rows)==json.loads((new/'run.json').read_bytes())['account_field_review_rows']
    worklists={}
    for label,f in [('cure','manual_review_handoff.csv'),('field_research','account_field_review.csv'),('missing_date','field25_source_exceptions.csv')]:
        worklists[label]=set(row['account'] for row in csvrows(new/f))
    scope=Counter(row['field25_review_scope'] for row in reviews)
    assert all(row['servicing_next_step'] for row in reviews)
    overlaps={a+'_and_'+b:len(x&worklists[b]) for a,x in worklists.items() for b in worklists if a<b}
    preissue_summary={'prior_preissue_clears':len(preissue_rows),'retained_clear':sum(r['kept_clear'] for r in preissue_rows),
        'source_onset_observed':sum(r['source_onset_represented'] for r in preissue_rows),
        'current_or_unknown_in_interval':sum(r['original_current_or_unknown_observed'] for r in preissue_rows)}
    clear_change={'preceding':len(previous_clears),'successor':len(cleared_ids),'removed':sorted(previous_clears-set(cleared_ids)),
        'added': sorted(set(cleared_ids)-previous_clears)}
    log=(new/'module2.log').read_text()
    qa={}
    for k,h in {'status':'remediated_account_status_17a | clear_account_status_17a','php':'remediated_full_php','dofd':'remediated_date_of_first_delinquency | clear_date_of_first_delinquency'}.items():
        if k=='php':
            h=next(line for line in log.splitlines() if [v.strip() for v in line.split('|')][:3] == ['account','full_php','remediated_full_php'])
        printed=qa_ids(log,h);ids=ordered_ids[k];assert printed==ids[:100]
        qa[k]={'eligible':len(ids),'printed':len(printed)}
    return {'pass':True,'baseline_database':json.loads((old/'run.json').read_bytes())['database'],'successor_database':json.loads((new/'run.json').read_bytes())['database'],
        'reviewed_accounts':count,'field_policy_marker_count':dict(policy_pairs),
        'changed_effective_fields_or_clear_actions':action_changes,'clears_before_after':clear_change,
        'prior_preincident_clear_followup':preissue_summary,'prior_preincident_accounts':preissue_rows,
        'worklist_intersections':overlaps,'worklist_sizes':{k:len(v) for k,v in worklists.items()},
        'field_research_field25_scopes':scope,'identical_original_and_proposed_month_tuples':months,'native_accounts_with_changed_preexisting_fields':len(differences),'field_differences':field_counts,'changed_rows':differences,
        'additional_successor_fields':sorted(newcols),'account_field_research_reasons':reason_counts,'account_field_review_rows':len(reason_rows),
        'historical_17b_required_with_empty_modeled_rating_by_effective_status':missing_model,'field25_dispositions':dofd_actions,'cleared_source_date_relative_to_incident':source_date_position,'printed_qa_checks':qa,
        'account_17899_rank_among_eligible_qa15':ordered_ids['dofd'].index(17899)+1 if 17899 in ordered_ids['dofd'] else None,'compared_native_csvs':csv_diffs}
if __name__=='__main__':
    old,new,out=map(Path,sys.argv[1:]);result=compare(old,new);out.write_text(json.dumps(result,indent=2)+'\n')
    print(result['reviewed_accounts'],result['native_accounts_with_changed_preexisting_fields'],result['account_field_research_reasons'])

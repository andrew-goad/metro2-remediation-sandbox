"""Independent CSV-to-XLSX validation including Excel value types, filters, freeze panes and notes."""
import csv
from collections import Counter
from datetime import datetime
import hashlib
import json
from itertools import zip_longest
from pathlib import Path
import sys
import zipfile

import openpyxl


def compare(csv_path, book_path, verified_rows=None):
    with csv_path.open(encoding='utf-8-sig',newline='') as f:
        reader=csv.DictReader(f)
        source=list(reader); fields=reader.fieldnames
    if verified_rows is not None:
        assert len(source) == int(verified_rows)
    with zipfile.ZipFile(book_path) as z:
        assert z.testzip() is None
        assert not any('vba' in s.lower() or 'externallink' in s.lower() for s in z.namelist())
    wb = openpyxl.load_workbook(book_path, data_only=False)
    assert wb.sheetnames == ['Review queue','How to review']
    sheet,guide=wb.worksheets
    assert sheet.freeze_panes == 'B2' and sheet.auto_filter.ref == 'A1:AC'+str(len(source)+1)
    assert sheet.max_row == len(source)+1 and sheet.max_column == 29
    assert [cell.value for cell in sheet[1]]==['Account ID','Review reason','Next review action','Bank impact start','Bank impact end','Credit impact start','Credit impact through','Reporting as of','Latest original month','Original status (17A)','Original history (newest first)','Post-impact months','Current streak start','Current streak months','Months required for cure','Earliest next history month','Proposed treatment','Proposed history (newest first)','Internal fields to clear','Original internal modeled payment rating','Original standard 17B (2020)','Original delinquency date (Field 25)','Proposed status (17A)','Proposed internal modeled payment rating','Proposed standard 17B (2020)','Proposed delinquency date (Field 25)','Reviewer','Disposition','Reviewer notes']
    assert guide['B1'].value=='How to review the queue' and format(len(source),',')+' synthetic accounts' in guide['B2'].value
    assert 'yet-unobserved' in guide['B7'].value and 'cannot establish cure' in guide['B7'].value
    assert '17B' in guide['B10'].value and 'Field 25' in guide['B10'].value and 'UNAVAILABLE_IN_SOURCE' in guide['B11'].value and 'complet' in guide['B12'].value and '(DA)' in guide['B13'].value
    assert 'proxy for a reversal' in guide['B14'].value
    messages=[str(guide.cell(row,2).value) for row in range(1,guide.max_row+1)]
    assert any('standard 426-character' in x and '00000000' in x and 'current CDIA CRRG' in x for x in messages)
    assert any("December's second byte stays 1" in x and "January's first PHP byte changes from 1 to D" in x and '17A 71 to 11' in x and 'February 1' in x for x in messages)
    assert any('zero cure months' in x and 'March 1 snapshot' in x and 'severe event' in x for x in messages)
    assert any('24064' in v and 'Account ID' in v and 'November' in v for v in messages)
    assert any('May performance' in v and 'June 1' in v for v in messages)
    counts=Counter()
    sample={}
    for row, cells in zip_longest(source,sheet.iter_rows(min_row=2,max_row=sheet.max_row)):
        assert cells is not None and row is not None
        # Compare by the 24 source columns, keeping the two added interpretation columns separate.
        displays=cells
        cells=displays[:20]+displays[21:24]+displays[25:]
        for status_name,rating_name,applicability in [('original_status_17a','original_payment_rating_17b',displays[20]),('proposed_effective_status_17a','proposed_effective_rating_17b',displays[24])]:
            status=row[status_name]; rating=row[rating_name]
            if not status.strip(): expected='Unknown: verify source status'
            elif status in ('DA','DF'):expected='Whole-account deletion instruction'
            elif status in ('05','13','65','88','89','94','95'):
                expected='Required: verify rating from source' if rating.strip() else 'Required: modeled rating missing'
            else:expected='Blank for this status'
            assert applicability.value==expected,(row['account'],status,rating,applicability.value)
            counts['applicability_notes_verified']+=1
        for i,key in enumerate(fields):
            val=cells[i].value
            assert cells[i].data_type!='f'
            if not row[key]: assert val is None,(key,val)
            elif i in (3,4,5,6,7,8,12,15,20,23):
                assert isinstance(val,datetime) and cells[i].is_date and val.strftime('%Y-%m-%d')==row[key]
                counts['typed_dates']+=1
            elif i in (11,13,14): assert val==int(row[key]) and cells[i].data_type=='n'
            else:
                assert cells[i].data_type=='s' and val==row[key],(i,key,val,row[key])
                if i in (10,17):
                    assert cells[i].number_format=='@'; counts['histories_as_text']+=1
                    if val.startswith('0'): counts['histories_starting_zero']+=1
                    if val.isdigit(): counts['all_digit_histories']+=1
        if 'DOFD' in row['internal_fields_to_clear'].split(', '):
            assert isinstance(cells[20].value,datetime) and cells[23].value is None
            assert cells[21].data_type == 's' and cells[22].data_type == 's'
            counts['explicit_dofd_clears_with_original_date_and_blank_proposal']+=1
        if row['account']=='17899':
            sample=dict(original_status=cells[9].value, original_rating=cells[19].value, original_dofd=cells[20].value.date().isoformat(), proposed_status=cells[21].value, proposed_rating=cells[22].value, proposed_dofd=cells[23].value, clear_instruction=cells[18].value,original_php=cells[10].value,proposed_php=cells[17].value)
        assert all(c.value is None for c in cells[len(fields):]); counts['source_cells_checked']+=len(fields)
    if any(row['account']=='17899' for row in source):
        assert sample==dict(original_status='71',original_rating='1',original_dofd='2024-12-01',proposed_status='11',proposed_rating='0',proposed_dofd=None,clear_instruction='DOFD',original_php='110000000',proposed_php='D10000000')
    assert not any(cell.data_type=='f' for cell in guide._cells.values())
    return dict(pass_all=True, reader='openpyxl '+openpyxl.__version__,rows=len(source),source_columns=len(fields),
        csv_sha256=hashlib.sha256(csv_path.read_bytes()).hexdigest(),workbook_sha256=hashlib.sha256(book_path.read_bytes()).hexdigest(),
        filter=sheet.auto_filter.ref,freeze=sheet.freeze_panes,sheets=wb.sheetnames,checked=dict(counts),account_17899=sample)

if __name__=='__main__':
    receipt=compare(Path(sys.argv[1]),Path(sys.argv[2]),sys.argv[3] if len(sys.argv)>3 else None)
    print(json.dumps(receipt,indent=2))

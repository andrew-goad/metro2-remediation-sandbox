"""Compare the per-account handoff to its complete independently exported account histories."""
import argparse
import csv
from collections import Counter
from datetime import date
from hashlib import sha256
from itertools import takewhile, zip_longest
import json
from pathlib import Path

COLUMNS = ('account review_reason review_action bank_impact_start bank_impact_end credit_impact_start '
           'credit_impact_through reporting_as_of latest_history_month original_status_17a '
           'original_php_newest_first post_impact_months current_streak_start current_streak_months '
           'cure_months_required next_history_month proposed_treatment proposed_php_newest_first '
           'internal_fields_to_clear original_payment_rating_17b original_dofd proposed_effective_status_17a '
           'proposed_effective_rating_17b proposed_effective_dofd').split()
ACTIONS = {'INSUFFICIENT_POST_IMPACT_HISTORY': 'Collect the next original reporting month and reassess cure.',
           'NO_CURE_OPEN_ACCOUNT': 'Review the unresolved impact and reassess cure with the next original reporting month.'}
def records(path):
    with path.open(encoding='utf-8') as f:
        if f.readline().strip() != 'window.METRO2_DATA={"accounts":[':
            raise ValueError('Expected the full build_explorer.py export')
        decoder = json.JSONDecoder()
        for line in f:
            yield decoder.raw_decode(line)[0]
def next_calendar_month(iso_date):
    d = date.fromisoformat(iso_date)
    year, mm = divmod(d.year * 12 + d.month, 12)
    return date(year, mm + 1, 1).isoformat()
def expected_row(r):
    recent = [m for m in r['months'] if m[0] > r['impact_end_date']]
    streak = list(takewhile(lambda m: m[1] == '0', recent))
    if r['credit_cure_date'] is not None or r['remediation_treatment'] == 'TRADELINE_DELETION':
        raise ValueError(f"Ineligible final-table queue member {r['account']}")
    clear = ', '.join(code for code, field in [('17A','account_status_17a'),('17B','payment_rating_17b'),('DOFD','date_of_first_delinquency')]
                      if r['clear_'+field] is True)
    effective = []
    for field in ('account_status_17a','payment_rating_17b','date_of_first_delinquency'):
        if r['clear_'+field] is True:
            effective.append(None)
        elif r['remediated_'+field] is not None:
            effective.append(r['remediated_'+field])
        elif r['clear_'+field] is False:
            effective.append(r[field])
        else:
            effective.append(None)
    action=ACTIONS[r['manual_review_reason']]
    if r['remediation_treatment']=='FULL_DEROGATORY_PHP_CLEANUP':
        action=(f"Severe month {r['last_severe_month'][:7]}. Reversal proxy {r['severe_reversal_month'][:7]}. "
                "Verify the reversal in servicing records and reassess cure with the next original month.")
    values = (r['account'],r['manual_review_reason'],action,
              r['impact_start_date'],r['impact_end_date'],r['credit_impact_start_date'],r['credit_impact_end_date'],
              r['latest_doai'],r['months'][0][0],r['account_status_17a'],
              ''.join(m[1] for m in r['months']),len(recent),
              streak[-1][0] if streak else '',len(streak),r['cure_consecutive_months_required'],
              next_calendar_month(r['months'][0][0]),r['remediation_treatment'],r['remediated_full_php'],clear,
              r['payment_rating_17b'],r['date_of_first_delinquency'],*effective)
    return {k: str(v) if v is not None else '' for k,v in zip(COLUMNS,values,strict=True)}
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('full_export',type=Path)
    p.add_argument('queue',type=Path)
    p.add_argument('receipt',type=Path)
    p.add_argument('output',type=Path)
    p.add_argument('--previous-full',type=Path)
    a=p.parse_args()
    run=json.loads(a.receipt.read_text())
    queue=[]; prior=records(a.previous_full) if a.previous_full else None
    count=0; months=0
    for row in records(a.full_export):
        if prior is not None and row != next(prior, None):
            raise ValueError(f"Native account differs from the previous release at {row['account']}")
        count+=1;months+=len(row['months'])
        if row['manual_review_flag']==1:
            expected=expected_row(row)
            queue.append(expected)
    if prior is not None and next(prior,None) is not None: raise ValueError('Previous release contains extra accounts')
    queue.sort(key=lambda row:(row['next_history_month'],int(row['account'])))
    with a.queue.open(newline='',encoding='utf-8-sig') as f:
        reader=csv.DictReader(f,strict=True)
        if reader.fieldnames != COLUMNS: raise ValueError('Unexpected queue columns')
        for actual,wanted in zip_longest(reader,queue):
            if actual!=wanted:
                detail=([key for key in COLUMNS if actual[key]!=wanted[key]] if actual and wanted else 'different row count')
                raise ValueError(f'Queue mismatch at {wanted and wanted["account"]}: {detail}')
    sha=sha256(a.queue.read_bytes()).hexdigest()
    if (count,len(queue),sha,COLUMNS)!=(run['account_count'],run['manual_review_handoff_rows'],
                                        run['manual_review_handoff_sha256'].lower(),run['manual_review_handoff_columns']):
        raise ValueError('Run manifest does not match verified export')
    if run['manual_review_handoff_schema'] != 'v2': raise ValueError('Expected schema v2')
    out={'pass':True,'database':run['database'],'source_accounts':count,'source_months':months,
         'queue_rows':len(queue),'columns_checked':len(COLUMNS),'queue_csv_sha256':sha,
         'review_reasons':dict(Counter(row['review_reason'] for row in queue)),
         'current_streak_counts':dict(Counter(row['current_streak_months'] for row in queue)),
         'rows_with_clear_actions':sum(bool(row['internal_fields_to_clear']) for row in queue),
         'matches_prior_explorer_accounts_and_all_months':prior is not None,
         'excluded_unflagged':count-len(queue)}
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out))
if __name__=='__main__': main()

"""Compare three actual PostgreSQL exports, verifying account, original-month and cure input identity."""
from collections import Counter
from datetime import date
from itertools import zip_longest
import argparse
import json
from pathlib import Path

STAGES = ('published','superseded_private','corrected')
INPUTS = (
    'account','profile_type','latest_doai','date_closed','full_php','php_left_byte_date','php_right_byte_date',
    'account_status_17a','payment_rating_17b','date_of_first_delinquency','impact_start_date','impact_end_date',
    'credit_impact_start_date','credit_impact_end_date','credit_cure_date','cure_consecutive_months_required',
    'post_impact_month_count','has_derog_in_credit_window','has_delinquency_in_credit_window','blueprint_alignment')
FIELDS = ('account_status_17a','payment_rating_17b','date_of_first_delinquency')

def records(path):
    dec=json.JSONDecoder()
    with path.open(encoding='utf-8') as src:
        if src.readline().strip() != 'window.METRO2_DATA={"accounts":[': raise ValueError('Expected a full explorer export')
        for line in src: yield dec.raw_decode(line)[0]

def dim(x):
    return (x['remediation_treatment'], x['manual_review_flag'], x['manual_review_reason'],
            x['remediated_full_php'],x['remediation_fields_modified'],x['remediation_applied_flag'],
            *((x['remediated_'+f], bool(x.get('clear_'+f))) for f in FIELDS))

def total(stats, row):
    stats['accounts']+=1
    stats[row['remediation_treatment']]+=1
    stats['represented_months']+=len(row['months'])
    changed=sum(o!=m for _,o,m,_ in row['months'])
    stats['edited_months']+=changed
    stats['accounts_with_monthly_edits']+=bool(changed)
    stats['confirmed_cures']+=row['credit_cure_date'] is not None
    stats['reviews']+=row['manual_review_flag']
    if row['manual_review_reason']: stats[row['manual_review_reason']]+=1
    for f in FIELDS: stats['clear_'+f]+=bool(row.get('clear_'+f))

def compare(paths):
    stats={s:Counter() for s in STAGES}
    history={pair:{'route_changes':Counter(),'accounts_with_changed_instructions':0,
                   'changed_month_proposals':0,'changed_clear_instructions':Counter(),'changed_treatment_ids':[]}
             for pair in ('published_to_corrected','superseded_to_corrected','published_to_superseded')}
    severe=Counter()
    case327=None
    for triple in zip_longest(*(records(p) for p in paths)):
        if None in triple: raise ValueError('Cohort size differs')
        old,inter,new=triple; ident=new['account']
        for ref in (old,inter):
            if any(ref[k]!=new[k] for k in INPUTS): raise ValueError(f'Original, incident, or cure differs for {ident}')
            if any(None in (a,b) or (a[0],a[1],a[3])!=(b[0],b[1],b[3])
                   for a,b in zip_longest(ref['months'],new['months'])):
                raise ValueError(f'Original monthly evidence differs for {ident}')
        for st,row in zip(STAGES,triple): total(stats[st],row)
        for before,after,label in ((old,new,'published_to_corrected'),(inter,new,'superseded_to_corrected'),(old,inter,'published_to_superseded')):
            d=history[label]
            if dim(before)!=dim(after): d['accounts_with_changed_instructions']+=1
            for f in FIELDS: d['changed_clear_instructions'][f]+=bool(before.get('clear_'+f))!=bool(after.get('clear_'+f))
            ct=sum(a[2]!=b[2] for a,b in zip(before['months'],after['months']))
            d['changed_month_proposals']+=ct
            if before['remediation_treatment']==after['remediation_treatment']:continue
            d['route_changes'][before['remediation_treatment']+' -> '+after['remediation_treatment']]+=1
            d['changed_treatment_ids'].append({'account':ident,'before':before['remediation_treatment'],'after':after['remediation_treatment'],
                 'bank_start':new['impact_start_date'],'bank_end':new['impact_end_date'],'credit_through':new['credit_impact_end_date'],
                 'cure_start':new['credit_cure_date'],'latest_in_window_severe_month':new['last_severe_month'],
                 'subsequent_numeric_month':new['severe_reversal_month'],'review_before':before['manual_review_reason'],
                 'review_after':after['manual_review_reason'],'changed_month_proposals':ct})
        if new['last_severe_month']:
            l=next(v[1] for v in new['months'] if v[0]==new['last_severe_month'])
            tag='reversed' if new['severe_reversal_month'] else 'unresolved'
            severe[tag]+=1; severe[tag+'_latest_'+l]+=1
            if new['credit_cure_date']: severe[tag+'_cured']+=1
            if new['manual_review_flag']: severe[tag+'_under_review']+=1
        if ident==327:
            case327={k:new[k] for k in ('account','impact_start_date','impact_end_date','last_severe_month','severe_reversal_month','credit_impact_end_date','credit_cure_date','last_severe_month','manual_review_reason','full_php','remediated_full_php')}
            case327['treatment_history']={s:x['remediation_treatment'] for s,x in zip(STAGES,triple)}
    return {'source_identity':{'identical_accounts_incidents_credit_windows_cure_dates':stats['corrected']['accounts'],
                               'identical_original_dated_months_and_window_flags':stats['corrected']['represented_months']},
            'counts':stats,'corrected_latest_severe_events':severe,'comparisons':history,'example_327':case327}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('published',type=Path);p.add_argument('superseded',type=Path);p.add_argument('corrected',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args(); result=compare((a.published,a.superseded,a.corrected)); a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'identity':result['source_identity'],'counts':result['counts']['corrected'],'routing':{k:v['route_changes'] for k,v in result['comparisons'].items()}}))

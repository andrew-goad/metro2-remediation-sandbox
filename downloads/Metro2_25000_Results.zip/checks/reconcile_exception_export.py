"""Compare the SQL exception handoff with source and proposed values in a native export."""
import argparse
import csv
import json
from collections import Counter
from datetime import date
from pathlib import Path
from audit_dates import ADVERSE_STATUS, DOFD, RATING, STATUS, effective

def reconcile(study):
    accounts = json.loads((study/'full.js').read_text().split('=',1)[1].strip().rstrip(';'))['accounts']
    with (study/'field25_source_exceptions.csv').open(encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        csv_cols = reader.fieldnames
        actual = list(reader)
    required_cols = {'account','reporting_as_of','latest_history_month','source_status_17a','source_rating_17b','source_field25','effective_status_17a','effective_rating_17b','effective_field25','exception_reason','date_evidence_gap','proposed_action','bank_impact_start','bank_impact_end','credit_impact_start','credit_impact_through','cure_start','cure_confirmed_through','proposed_treatment','bank_cure_review_flag','bank_cure_review_reason'}
    assert set(csv_cols) == required_cols and len(csv_cols) == len(required_cols)
    expected = {}
    reasons = Counter()
    statuses = Counter()
    for row in accounts:
        status, rating, field25 = (effective(row, f) for f in (STATUS,RATING,DOFD))
        if row['remediation_treatment']=='TRADELINE_DELETION' or field25 is not None:
            continue
        if status in ADVERSE_STATUS:
            reason = 'DATE_REQUIRED_BY_STATUS'
        elif status in ('05','13') and rating in set('123456GL'):
            reason = 'DATE_REQUIRED_BY_STATUS_AND_RATING' if status=='13' else 'DATE_REQUIRED_BY_HISTORICAL_05_AND_RATING'
        else:
            continue
        reasons[reason] += 1
        statuses[status] += 1
        threshold_end = None
        if row['credit_cure_date']:
            first = date.fromisoformat(row['credit_cure_date'])
            final_month = first.year*12 + first.month - 1 + row['cure_consecutive_months_required'] - 1
            threshold_end = str(date(final_month//12,final_month%12+1,1))
        vals = {
            'account':row['account'], 'reporting_as_of':row['latest_doai'], 'latest_history_month':row['php_left_byte_date'],
            'source_status_17a':row[STATUS], 'source_rating_17b':row[RATING], 'source_field25':row[DOFD],
            'effective_status_17a':status, 'effective_rating_17b':rating,'effective_field25':field25,
            'exception_reason':reason, 'date_evidence_gap':'DATE_CLEARED_BY_PROPOSAL' if row['clear_'+DOFD] else 'DATE_ABSENT_IN_SOURCE',
            'bank_impact_start':row['impact_start_date'], 'bank_impact_end':row['impact_end_date'], 'credit_impact_start':row['credit_impact_start_date'],
            'credit_impact_through':row['credit_impact_end_date'], 'cure_start':row['credit_cure_date'], 'cure_confirmed_through':threshold_end,
            'proposed_treatment':row['remediation_treatment'], 'bank_cure_review_flag':row['manual_review_flag'], 'bank_cure_review_reason':row['manual_review_reason']
        }
        expected[row['account']] = {k:'' if v is None else str(v) for k,v in vals.items()}
    actual_keys = [int(row['account']) for row in actual]
    assert actual_keys == sorted(expected), (actual_keys, sorted(expected))
    for row in actual:
        key = int(row['account'])
        suggested = row.pop('proposed_action')
        assert suggested and 'servicing' in suggested.lower() and 'delinquen' in suggested.lower()
        assert row == expected[key], (key,row,expected[key])
    return {'account_count':len(accounts),'exceptions':len(expected),'scope_codes':dict(sorted(statuses.items())),
            'source_and_effective_fields_match':True,'bank_and_cure_dates_match':True,'distinct_ordered_ids_match':True,'exception_reasons':dict(reasons),
            'overlap_with_bank_review':sum(int(r['bank_cure_review_flag']) for r in actual),
            'schema_columns':len(required_cols),'result':'pass'}


if __name__ == '__main__':
    p=argparse.ArgumentParser();p.add_argument('study',type=Path);p.add_argument('receipt',type=Path)
    args=p.parse_args(); result=reconcile(args.study)
    args.receipt.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

SELECT jsonb_build_object(
 'account_status_17a', count(*) FILTER (WHERE clear_account_status_17a),
 'payment_rating_17b', count(*) FILTER (WHERE clear_payment_rating_17b),
 'date_of_first_delinquency', count(*) FILTER (WHERE clear_date_of_first_delinquency),
 'accounts_with_any_clear', count(*) FILTER (WHERE clear_account_status_17a OR clear_payment_rating_17b OR clear_date_of_first_delinquency),
 'null_flags', count(*) FILTER (WHERE clear_account_status_17a IS NULL OR clear_payment_rating_17b IS NULL OR clear_date_of_first_delinquency IS NULL),
 'deletions_with_any_clear', count(*) FILTER (WHERE remediation_treatment='TRADELINE_DELETION' AND (clear_account_status_17a OR clear_payment_rating_17b OR clear_date_of_first_delinquency))
)
FROM module2.metro2_remediation_final;

"""Inspect, independently, how the exported sandbox actions would affect retained records."""
import argparse
import csv
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

ADVERSE_STATUS = set('61 62 63 64 65 71 78 80 82 83 84 88 89 93 94 95 96 97'.split())
ADVERSE_PHP = set('123456GHJKL')
MAJOR = set('GHJKL')
NUMERIC = set('123456')
STATUS = 'account_status_17a'
RATING = 'payment_rating_17b'
DOFD = 'date_of_first_delinquency'


def effective(account, field):
    if account['clear_' + field]:
        assert account['remediated_' + field] is None
        return None
    change = account['remediated_' + field]
    return change if change is not None else account[field]


def inspect(path, out):
    out.mkdir(parents=True, exist_ok=True)
    raw = path.read_bytes()
    accounts = json.loads(raw.decode().split('=', 1)[1].strip().rstrip(';'))['accounts']
    distribution = defaultdict(Counter)
    examples = {}
    exceptions = []
    rows = []
    cleared = []
    for a in accounts:
        status, rating, date = (effective(a, field) for field in (STATUS, RATING, DOFD))
        src_status, src_rating, src_date = (a[field] for field in (STATUS, RATING, DOFD))
        deleted = a['remediation_treatment'] == 'TRADELINE_DELETION'
        assert deleted == (status == 'DA')
        if deleted:
            assert not a['clear_' + DOFD] and a['remediated_' + DOFD] is None
            action = 'delete tradeline'
        elif a['clear_' + DOFD]:
            assert src_date and date is None
            action = 'clear date'
        elif a['remediated_' + DOFD] is not None:
            assert date != src_date
            action = 'set date'
        else:
            action = 'retain supplied date' if date else 'already absent'
        history = a['months']
        assert history and [m[0] for m in history] == sorted((m[0] for m in history), reverse=True)
        prefix = []
        for month in history:
            if month[2] not in ADVERSE_PHP:
                break
            prefix.append(month)
        expected_dt = min((m[0] for m in prefix if m[2] in NUMERIC), default=None)
        inwindow = [m for m in history if m[3]]
        missing = (not deleted and not date and (status in ADVERSE_STATUS or (status in ('05','13') and rating in set('123456GL'))))
        adverse_after = [m for m in history if m[2] in ADVERSE_PHP]
        major_after = [m for m in history if m[2] in MAJOR]
        if src_date:
            date_position = 'before' if src_date < a['credit_impact_start_date'] else 'after' if src_date > a['credit_impact_end_date'] else 'inside'
        else:
            date_position = 'no source date'
        row = {
            'account': a['account'], 'treatment': a['remediation_treatment'], 'action': action,
            'source_status': src_status, 'source_rating': src_rating, 'source_date': src_date,
            'effective_status':status, 'effective_rating': None if deleted else rating, 'effective_date': None if deleted else date,
            'date_closed': a['date_closed'], 'profile':a['profile_type'], 'bank_start':a['impact_start_date'],
            'bank_end':a['impact_end_date'], 'credit_start':a['credit_impact_start_date'], 'credit_end':a['credit_impact_end_date'],
            'cure_start':a['credit_cure_date'], 'post_bank_months':a['post_impact_month_count'],
            'latest_history':history[0][0], 'latest_original': history[0][1], 'latest_proposed': history[0][2],
            'review':a['manual_review_flag'], 'review_reason':a['manual_review_reason'],
            'date_position_relative_to_credit_window': date_position, 'oldest_retained_adverse':adverse_after[-1][0] if adverse_after else None,
            'latest_retained_adverse':adverse_after[0][0] if adverse_after else None, 'retained_major_months':len(major_after),
            'retained_adverse_months': len(adverse_after), 'proposed_active_adverse_suffix_months': len(prefix),
            'proposed_active_suffix_oldest_numeric_month':expected_dt,
            'edits':sum(m[1]!=m[2] for m in history), 'missing_by_historical_status_and_rating':missing
        }
        rows.append(row)
        def count(key, *parts):
            distribution[key][' | '.join('null' if p is None else str(p) for p in parts)]+=1
        count('actions', action)
        if deleted:
            count('deletions_by_original_date',bool(src_date))
        else:
            count('retained_status_original_and_effective_date',status,'source present' if src_date else 'source absent','proposed present' if date else 'proposed absent')
            count('effective_status_rating_and_action',status,rating,action)
            count('effective_status_and_action',status, action)
            if missing:
                exceptions.append(row)
                count('missing_by_status',status)
                count('missing_by_status_treatment',status,a['remediation_treatment'])
                count('missing_by_review_placement',bool(a['manual_review_flag']),a['manual_review_reason'])
                examples.setdefault('missing_date_status_'+status, row)
            if date:
                count('carried_date_in_active_run',expected_dt==date)
        if action == 'clear date':
            assert not date and src_date and a['date_closed'] is None
            assert a['remediation_treatment']=='SIMPLE_DELINQUENCY_PHP_CLEANUP'
            assert history[0][1] in NUMERIC and history[0][2]=='D' and history[0][3]==1
            assert (status,rating)==('11','0') and not prefix and not a['has_derog_in_credit_window']
            assert a['credit_cure_date'] is None and a['manual_review_flag']==1
            cleared.append(row)
            for k, parts in {
                    'clears_by_original_status_rating':(src_status,src_rating), 'clears_by_effective_status_rating':(status,rating),
                    'clears_by_reason':(a['manual_review_reason'],), 'clears_by_old_date_position':(date_position,),
                    'clears_by_adverse_history_remaining':(bool(adverse_after),), 'clears_by_major_history_remaining':(bool(major_after),),
                    'clears_major_before_or_after_window':(any(m[0]<a['credit_impact_start_date'] for m in major_after),any(m[0]>a['credit_impact_end_date'] for m in major_after)),
                    'clears_old_date_month_as_reported':(next((f'{b} to {c}' for dt,b,c,_ in history if dt==src_date),'not represented'),),
                    'clears_by_corrected_post_bank_entries':(any(m[0]>a['impact_end_date'] and m[1]!=m[2] for m in history),),
                    'clears_old_date_versus_bank_period':('before' if src_date<a['impact_start_date'] else 'after' if src_date>a['impact_end_date'] else 'inside',),
                    'clears_with_held_prebank_adverse_and_all_postbank_suppressed':(bool(adverse_after),)
            }.items(): count(k,*parts)
            if src_status=='71' and len(history)<=16:
                example = {**row, 'months_oldest_first':history[::-1]}
                if date_position=='before' and adverse_after:
                    examples.setdefault('retained_earlier_history_at_clear',example)
                if date_position=='inside' and not major_after and not adverse_after and len(inwindow)>=2:
                    examples.setdefault('simple_in_window_clear',example)
            if major_after:
                examples.setdefault('retained_earlier_major_at_clear',{**row,'months_oldest_first':history[::-1]})
    def write_csv(filename, entries):
        with (out/filename).open('w', newline='') as f:
            writer=csv.DictWriter(f,fieldnames=rows[0]); writer.writeheader();writer.writerows(entries)
    for filename,entries in [('all-account-date-actions.csv',rows),('cleared-account-date-actions.csv',cleared),('retained-missing-date-exceptions.csv',exceptions)]:
        write_csv(filename,entries)
    assert len(rows)==len({r['account'] for r in rows})
    report={'source_sha256':hashlib.sha256(raw).hexdigest(),'source':str(path),'accounts':len(rows),'cleared':len(cleared),'retained_missing_despite_2020_status_rating_criterion':len(exceptions),
            'distributions':{key:dict(sorted(value.items())) for key,value in sorted(distribution.items())},'examples':examples}
    (out/'date-actions-summary.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('export', type=Path); parser.add_argument('out', type=Path)
    args=parser.parse_args()
    r=inspect(args.export,args.out)
    print('accounts',r['accounts'],'clears',r['cleared'],'status-rating-missing',r['retained_missing_despite_2020_status_rating_criterion'])
    for key,vals in r['distributions'].items():
        if key.startswith('clears') or key.startswith('missing') or key.startswith('carried_date'):
            print(key,vals)
    print('EXAMPLES',[(k,v['account']) for k,v in r['examples'].items()])

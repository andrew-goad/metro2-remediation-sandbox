# Read the study results

For the 25,000-account bank-issue investigation, open manual_review_handoff.xlsx and filter Account ID to 24064. Check the incident and credit-impact dates, compare its monthly marks and identify the next original observation. The separate servicing and missing-date files address different questions. Read RETAINED_25000.md before comparing source or code versions.

**Test the strategy on the same 1,000 accounts.** The new three- and four-month native runs share the same 35,395 original dated account observations and incident dates. Confirmed cures fell from 555 to 494, ongoing cure reviews increased from 133 to 147, monthly edits increased from 461 to 496, and deletion proposals increased from 22 to 23. checks/runtime/threshold-comparison.json contains both source identities and complete input checks.

* **57** had three original current months, July through September 2025. On October 1 the three-month rule recognized July cure; the four-month rule kept it open for another observation.
* **975** had a September 2023–November 2024 bank issue. December 2024 through February 2025 were originally current. Under three months the credit window ended in November and cure was confirmed through February. Under four, March's delinquency ended that streak. Grades 1–6 through August led to September's unreversed L and the October 1 deletion proposal. Neither scenario made a monthly substitution or placed 975 on the cure queue. See checks/runtime/account-975.json.

Reproduce the comparison directly after extracting this archive. Both saved full exports carry the measured run and complete account evidence.

```powershell
python ./tools/compare_study_thresholds.py ./cohorts/1000/full.js ./cohorts/1000-cure4/full.js --output ./my-comparison.json
```

The result matches checks/runtime/threshold-comparison.json. The audited originals use separate paths, including audited_25000/cohorts/1000/ and audited_25000/cohorts/1000-cure4/. The current counterparts in cohorts/ carry their own module_02_configured.sql and run.json for each setting.

Use tools/RUN_STUDY.md to open the 187-account quickstart or to compare two policy choices in fresh databases. Use the same configured Module 2 file for a continuing incident. BUSINESS_REQUIREMENTS.md and VALIDATION.md give the business and validation context. The current 25,000-account viewer is an exhibit of the original audited study. Its preserved evidence and current code are separated in RETAINED_25000.md.

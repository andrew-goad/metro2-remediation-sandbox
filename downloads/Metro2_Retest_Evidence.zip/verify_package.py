"""Verify every file against the extraction manifest. Run from any directory."""
import hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
lines=(root/"SHA256SUMS.txt").read_text(encoding="utf-8").splitlines()
for line in lines:
    expected,name=line.split("  ",1)
    actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
    if actual!=expected:
        raise SystemExit("Checksum mismatch: "+name)
print(f"Verified {len(lines)} evidence and reproduction files.")

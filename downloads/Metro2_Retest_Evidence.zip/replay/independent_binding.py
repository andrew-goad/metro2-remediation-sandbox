"""Read the versioned full-export binding from its byte-level specification."""
import hashlib,json
FORMAT='metro2-full-export-v1'
def canonical(item):
    return json.dumps(item,ensure_ascii=True,allow_nan=False,separators=(',',':'),sort_keys=True).encode('ascii')
def digest(x):
    h=hashlib.sha256(b'metro2-full-export-v1\n')
    for row in x['accounts']:h.update(b'account\t'+canonical(row)+b'\n')
    fields={k:v for k,v in x['meta'].items() if k!='exportIntegrity'}
    h.update(b'metadata\t'+canonical(fields)+b'\n')
    return h.hexdigest()
def assert_genuine_binding(x):
    claimed=x['meta']['exportIntegrity']
    assert set(claimed)=={'format','sha256'} and claimed['format']==FORMAT and claimed['sha256']==digest(x), claimed
    return claimed['sha256']
def rebind_viewer(x):
    x['meta']['exportIntegrity']={'format':FORMAT,'sha256':digest(x)}
    assert_genuine_binding(x)

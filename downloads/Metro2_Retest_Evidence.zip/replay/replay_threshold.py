"""Observe the same genuine four-month study and wrong three-month follow-up on either released SQL version."""
import argparse
import getpass
import hashlib
import json
import os
from pathlib import Path
import sys

archive = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(archive/'successor/tests'))
from run_regression import fresh_database, invoke, psql_command

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument("version",choices=("audited","successor"))
parser.add_argument("--output",type=Path,required=True)
parser.add_argument("--host",default="localhost")
parser.add_argument("--port",type=int,default=5432)
parser.add_argument("--user",default="postgres")
parser.add_argument("--psql")
parser.add_argument("--prompt-password",action="store_true")
args=parser.parse_args()
if args.prompt_password:
    os.environ["PGPASSWORD"]=getpass.getpass("PostgreSQL password: ")
client=psql_command(args)
root=archive/args.version
configured=archive/'receipts'/('historical/auditor-k4' if args.version=='audited' else 'studies/1000-cure4')
stock=root/'src/module_02_metro2_remediation_engine.sql'
with fresh_database(client) as db:
    def execute(**kwargs):return invoke(client,db,**kwargs)
    def row():
        return json.loads(execute(sql="""SELECT jsonb_build_object('account',account,'cutoff',latest_doai,'threshold',
          cure_consecutive_months_required,'bank_start',impact_start_date,'bank_end',impact_end_date,'cure',
          credit_cure_date,'review',manual_review_flag,'reason',manual_review_reason)
          FROM module2.metro2_remediation_final WHERE account=57"""))
    def fingerprints():
        return {n:execute(sql=f"""SELECT count(*),md5(string_agg(to_jsonb(t)::text,'' ORDER BY to_jsonb(t)::text))
                     FROM module2.metro2_remediation_{n} t""") for n in ('input','window_eval','php_detail','final')}
    execute(file=configured/'module_01_configured.sql')
    four=configured/'module_02_configured.sql'
    execute(file=four)
    first=row()
    prefix="SET metro2.reuse_incident_dates='on';\n"
    execute(sql=prefix+four.read_text(encoding='utf-8'))
    same=row()
    before=fingerprints()
    try:
        execute(sql=prefix+stock.read_text(encoding='utf-8'))
        blocked=False
    except RuntimeError as err:
        if 'INCIDENT REUSE FAILED' not in str(err):
            raise
        blocked=True
    after=fingerprints()
    final=row()
    v=json.loads(execute(file=root/'tools/verify_study.sql',variables=['expected_accounts=1000','required_months=4']))
    receipt=dict(source=digest(stock),configured=digest(four),version=args.version,first=first,equal_cutoff=same,
                 wrong_file_blocked=blocked,before_fingerprints=before,after_fingerprints=after,
                 previous_tables_preserved=before==after,record_after_attempt=final,
                 four_month_verifier_pass=v['pass'],threshold_or_cure_mismatches=v['audit']['cure_start_or_threshold_mismatches'])
    expected=args.version=='successor'
    assert first==same and first['review']==1 and first['threshold']==4
    assert blocked==expected and (before==after)==expected and v['pass']==expected
    assert (final['threshold'],final['review'])==((4,1) if expected else (3,0))
    args.output.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(args.version, 'observed', final['threshold'], 'months; previous result preserved:',before==after)

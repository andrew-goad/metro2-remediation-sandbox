"""Independent recount from original monthly observations, bank dates and reporting status."""
from collections import Counter

def rederive(rows, k):
    reasons = Counter()
    mismatches = []
    for account in rows:
        # Ignore proposed symbols and the stored impact-window flag.
        raw = [(m, original) for m, original, _proposed, _window in reversed(account['months'])]
        post = [(m, code) for m, code in raw if m>account['impact_end_date']]
        run = []
        cure = None
        for date, mark in post:
            if mark!='0':
                run=[]
                continue
            run.append(date)
            if len(run)==k:
                cure = run[0]
                break
        inside = [(m,code) for m,code in raw if m>=account['impact_start_date'] and (not cure or m<cure)]
        ordinary = any(mark in '123456' for _,mark in inside)
        severe = max((m for m,mark in inside if mark in 'GHJKL'),default=None)
        later_numeric = bool(severe and any(m>severe and mark in '0123456' for m,mark in raw))
        open_account=account['account_status_17a'] not in ('13','61','62','63','64','65')
        reason=None
        if open_account and cure is None and (later_numeric if severe else ordinary):
            reason='INSUFFICIENT_POST_IMPACT_HISTORY' if len(post)<k else 'NO_CURE_OPEN_ACCOUNT'
        reasons[reason or 'NO_MONTHLY_REVIEW']+=1
        if (cure,int(reason is not None),reason)!=(account['credit_cure_date'],account['manual_review_flag'],account['manual_review_reason']):
            mismatches.append(account['account'])
    return {'threshold':k,'accounts':len(rows),'monthly_reviews':sum(n for reason,n in reasons.items() if reason!='NO_MONTHLY_REVIEW'),
            'reason_counts':dict(reasons),'mismatches':mismatches}

"""Compare ordinary and edited synthetic-study viewer files. No source/fixture edit in place."""
import argparse
import copy
import hashlib
import json
import pathlib
import subprocess
import sys
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('comparator',type=pathlib.Path)
parser.add_argument('first',type=pathlib.Path)
parser.add_argument('second',type=pathlib.Path)
parser.add_argument('out',type=pathlib.Path)
parser.add_argument('--binding',action='store_true')
opts=parser.parse_args()
sha=lambda b:hashlib.sha256(b).hexdigest()

def full(path):
    raw=path.read_text()
    return json.loads(raw.split('=',1)[1].strip().removesuffix(';'))

def wire(item):
    return json.dumps(item,ensure_ascii=True,separators=(',',':')).replace('<',r'\u003c')

def write(path, data):
    rows=data['accounts']; head='window.METRO2_DATA={"accounts":[\n'
    path.write_text(head+',\n'.join(wire(r) for r in rows)+'],"meta":'+wire(data['meta'])+'};\n')

def modify57(a,b):
    r=next(r for r in b['accounts'] if r['account']==57)
    assert r['manual_review_flag']==1 and r['manual_review_reason']=='INSUFFICIENT_POST_IMPACT_HISTORY'
    r['manual_review_flag']=0; r['manual_review_reason']=None

def relabel(a,b):
    b.clear();b.update(copy.deepcopy(a))
    for r in b['accounts']:r['cure_consecutive_months_required']=4

def subset(a,b):
    for data in [a,b]:
        assert data['accounts'][0]['account']==1
        data['accounts']=data['accounts'][1:]

def change_incident(a,b):
    b['accounts'][0]['impact_start_date']='1901-01-01'

def run(a,b,output):
    return subprocess.run([sys.executable,str(opts.comparator),str(a),str(b),'--output',str(output)],text=True,capture_output=True)

left=full(opts.first)
right=full(opts.second)
records={}
opts.out.parent.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory(dir=opts.out.parent) as td:
    td=pathlib.Path(td)
    output=td/'owner-prior-good.json'
    valid=run(opts.first,opts.second,output)
    assert valid.returncode==0,(valid.stdout,valid.stderr)
    good=output.read_bytes();result=json.loads(good)
    assert result['pass'] and [result[key]['monthly_cure_reviews'] for key in ['first','second']]==[133,147]
    def summarize(b):
        j=json.loads(b)
        return dict(monthly_cure_reviews=[j[k]['monthly_cure_reviews'] for k in ['first','second']],
                    accounts=[j[k]['accounts'] for k in ['first','second']],
                    months=[j[k]['represented_months'] for k in ['first','second']],
                    example_account=j['example']['account'])
    from monthly_evidence import rederive
    independent_recounts=[rederive(x['accounts'],k) for x,k in [(left,3),(right,4)]]
    assert [r['monthly_reviews'] for r in independent_recounts]==[133,147] and all(not r['mismatches'] for r in independent_recounts),independent_recounts
    genuine=summarize(good);genuine.update(independent_monthly_recounts=independent_recounts,output_sha256=sha(good),first_viewer_sha256=sha(opts.first.read_bytes()),second_viewer_sha256=sha(opts.second.read_bytes()))
    def test(label,mutation,rebind=False):
        a,b=copy.deepcopy(left),copy.deepcopy(right);mutation(a,b)
        if rebind:
            # Separate implementation supplied for the exporter's documented binding contract.
            from independent_binding import rebind_viewer
            for d in (a,b):rebind_viewer(d)
        left_file=td/'a.js';right_file=td/'b.js'
        write(left_file,a);write(right_file,b)
        output.write_bytes(good)
        c=run(left_file,right_file,output)
        final=output.read_bytes()
        d=dict(exit=c.returncode,accepted=c.returncode==0,prior_good_sha256=sha(good),after_sha256=sha(final),
               prior_good_bytes_preserved=final==good,stdout=c.stdout.strip(),stderr_last_line=c.stderr.strip().splitlines()[-1] if c.stderr.strip() else None)
        d['returned_result']=summarize(final)
        if rebind:d['independent_digest_recomputed']=True
        records[label]=d
    for label,func in [('changed_57_referral',modify57),('row_threshold_only',relabel),('same_999_rows_filtered',subset),('genuinely_changed_source',change_incident)]:
        test(label,func)
    if opts.binding:
        from independent_binding import assert_genuine_binding
        genuine['independently_recomputed_binding']=[assert_genuine_binding(x) for x in (left,right)]
        test('changed_57_referral_with_recomputed_local_binding',modify57,True)
        test('same_999_rows_filtered_with_recomputed_local_binding',subset,True)
        test('row_threshold_only_with_recomputed_local_binding',relabel,True)
        def missing_binding(a,b): b['meta'].pop('exportIntegrity')
        def invalid_binding(a,b): b['meta']['exportIntegrity']['sha256']='1'*64
        def wrong_configured(a,b):
            b['meta']['configuredModule2Sha256']=a['meta']['configuredModule2Sha256']
        def same_receipt(a,b):
            b['meta']['verifiedRun']=copy.deepcopy(a['meta']['verifiedRun'])
        test('missing_binding', missing_binding)
        test('edited_digest', invalid_binding)
        test('wrong_configured_engine_with_recomputed_local_binding',wrong_configured,True)
        test('copied_receipt_claims_with_recomputed_local_binding',same_receipt,True)
report={'comparator_sha256':sha(opts.comparator.read_bytes()),'first_module2_source_sha256':left['meta']['module2Sha256'],
        'configured_engine_sha256':[x['meta']['configuredModule2Sha256'] for x in (left,right)],
        'genuine':genuine,'cases':records}
opts.out.write_text(json.dumps(report,indent=2)+'\n')
if opts.binding:
    assert all(not r['accepted'] and r['prior_good_bytes_preserved'] for r in records.values()), records
else:
    assert [r['accepted'] for r in records.values()]==[True,True,True,False]
print(opts.out)

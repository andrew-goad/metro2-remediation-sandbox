# Developer retest · Two cure-threshold controls

The independent auditor’s disposition for the earlier private package beginning `a1c3b077` was **Ready after listed changes**. This packet records the developer’s targeted retest of those changes. Original synthetic histories, agreed bank-issue dates, field policy and correction elections remain available for comparison. Andrew retains the release decision.

## Read the findings

| What to inspect | Evidence in this packet |
| --- | --- |
| Correct two-policy result and three reported false comparisons | `receipts/comparison/paired.json` shows the native before/after counts, the false results on the audited build, exit codes and previous-output checksums after each failed comparison. The auditor’s supplied comparison and browser readbacks are beside it. |
| Same-incident four-month rule and wrong three-month SQL | `receipts/followup/paired.json` records account 57 under both builds, an advancing four-month follow-up, a separate fresh three-month comparison, and row counts plus table-content digests. The unchanged verifier found 1,000 mismatches only after the earlier engine had replaced the four-month decisions. |
| Results for account 975 | `receipts/studies/account-975.json` includes all ten original post-issue observations. The issue ran September 2023–November 2024. A three-month threshold established December cure, confirmed in February and observable March 1. Under four months, March delinquency interrupted the streak. An unresolved September charge-off remained inside the modeled impact window. Both proposals had zero monthly substitutions. |
| Ordinary studies and actual command | `receipts/studies/` holds the two current 1,000-account runs and the current 187-account, four-month guide run. `receipts/operator/` identifies the actual kit, operator-selected inputs and local browser result. The 25,000-account receipts in `receipts/historical/` describe the retained study independently regenerated during the preceding audit. |
| Previously closed findings | Both releases passed the earlier 48 and 55 assertions in fresh PostgreSQL test databases. `receipts/regression/` contains the native readbacks. The independent auditor’s 30 rejected exports apply to the audited package. In `receipts/historical/export-native-30.json`, 28 are seven contradictions across four invocation modes and two withhold 17899’s genuine date clear. All 30 preserved the preceding file. |

`Metro2_Developer_Retest.json` links each finding to its evidence and identifies the exact source and supplied audit by SHA-256. Verify the contents before rerunning. From the extracted folder in PowerShell, use the following command. On Linux or macOS use `python3` for `py -3`. The comparator replay scripts require Python 3.9 or later.

```powershell
py -3 .\verify_package.py
```

## Reproduce the saved comparison

Run the same comparison challenges against the two versions, using each version’s own exported input pair. No database or network connection is needed. Both intact pairs cover 1,000 accounts, 35,395 original account-months and 133 versus 147 open reviews. The three altered-file cases passed on the audited program and failed on the revised program. The JSON below records what each version actually did.

```powershell
py -3 .\replay\replay.py .\audited\tools\compare_study_thresholds.py .\inputs\audited\k3.js .\inputs\audited\k4.js .\my-audited-comparison.json
py -3 .\replay\replay.py .\successor\tools\compare_study_thresholds.py .\inputs\successor\k3.js .\inputs\successor\k4.js .\my-revised-comparison.json --binding
py -3 .\successor\tests\test_comparison_integrity.py .\inputs\successor\k3.js .\inputs\successor\k4.js --output .\my-repository-controls.json
```

A separately generated pair under `inputs/independent-retake/` reproduces the exact viewer identities in the independent developer challenge receipt. The same population regenerated in a different study can have a different whole-file checksum because run metadata also contributes to the export. Compare its original observations, incident dates, native decisions and thresholds. An unbound earlier viewer can still be inspected. Re-export from the retained database with its verified receipt to create a current comparison input.

## Reproduce same-incident follow-up

Use a PostgreSQL test login with permission to create databases and the `psql` client. The native tests ran on PostgreSQL 16.2. The two commands use separate test servers and only operate on randomly named databases created by the harness. Each uses the saved four-month configuration from its release and then selects that release’s stock three-month SQL on the same incident. Both write a receipt and clean up their own database.

```powershell
py -3 .\replay\replay_threshold.py audited --host localhost --port 5432 --user postgres --prompt-password --output .\my-audited-followup.json
py -3 .\replay\replay_threshold.py successor --host localhost --port 5433 --user postgres --prompt-password --output .\my-revised-followup.json
```

For all successor SQL tests, run the normal harness. It includes 11 new threshold-continuity controls, including eight rejections that must preserve all four complete result tables. To recheck the featured cases, use the current 1,000-account data and the retained 25,000-account data. The case receipt identifies each dataset’s actual engine hash.

```powershell
py -3 .\successor\tests\run_regression.py --host localhost --port 5433 --user postgres --prompt-password --threshold-evidence .\my-threshold-controls.json --audit-evidence .\my-48.json --followup-evidence .\my-55.json
py -3 .\successor\tests\verify_featured_cases.py --replay .\inputs\successor\k3.js --scale .\inputs\retained\scale.js --output .\my-four-cases.json
```

The original independent scripts are preserved under `auditor-inputs/` for source comparison. They follow the original audit directory layout. The portable commands above implement the same attacks in temporary folders and leave included study inputs intact. A local digest verifies file consistency against its recorded value. It does not authenticate an external provider or establish that a consumer’s real credit file was corrected.

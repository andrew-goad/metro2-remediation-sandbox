from pathlib import Path
import subprocess,json,tempfile
R=Path('metro3');S=R/'source';U=R/'ui';N=R/'native'
comp=U/'kit/tools/compare_study_thresholds.py'
x=N/'export1000.js';y=N/'exportfour.js'
def go(a,b,out):
 p=subprocess.run(['python3',str(comp),str(a),str(b),'--output',str(out)],capture_output=True,text=True)
 return [p.returncode,p.stderr.splitlines()[-1] if p.stderr else None]
with tempfile.TemporaryDirectory() as space:
 t=Path(space); desk=t/'r.json';result={}
 result['ordinary']=go(x,y,desk);assert result['ordinary'][0]==0;ref=json.loads((S/'docs/downloads/Metro2_Threshold_Comparison_1000.json').read_text());actual=json.loads(desk.read_text());assert all(ref[k]==actual[k] for k in ['first','second','identical_input_sha256','accounts_changed_by_measure','example'])
 ln=y.read_text().splitlines(True);p=json.loads(ln[1][:-2]);p['impact_start_date']='1901-01-01';single=t/'single.js';single.write_text(ln[0]+json.dumps(p)+',\n'+''.join(ln[2:]));result['genuinely_changed_input']=go(x,single,desk);assert result['genuinely_changed_input'][0]!=0
 result['prior_result_preserved']=json.loads(desk.read_text())==actual
 # Explicitly test restricted matched exports carrying the prior genuine receipts, to define comparison scope.
 a=t/'a.js';b=t/'b.js'
 for original,dest in [(x,a),(y,b)]:
  lines=original.read_text().splitlines(True)
  # discard only first account row in each file; embedded metadata still describes 1000 accounts.
  dest.write_text(lines[0]+''.join(lines[2:]))
 result['two_filtered_same_ids']=go(a,b,desk);limited=json.loads(desk.read_text())
 result['filtered_readback']={'pass':limited['pass'],'count':limited['first']['accounts'],'declared_in_source':1000,'months':limited['first']['represented_months']}
 print(json.dumps(result,indent=2));(U/'paired-reader.json').write_text(json.dumps(result,indent=2))

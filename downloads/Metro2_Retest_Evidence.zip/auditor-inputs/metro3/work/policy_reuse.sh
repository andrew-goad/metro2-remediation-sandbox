#!/usr/bin/env bash
set -eu
w=$(cd "$(dirname "$0")" && pwd)
p=${PG_BIN:-/tmp/metro-intake-pg/pgserver/pginstall/bin}
d=$(mktemp -d)
export PGPORT=58709 PGUSER=postgres PGHOST=127.0.0.1
"$p/initdb" -U postgres -E UTF8 -A trust --locale=C -D "$d/db" > "$d/init.log"
"$p/pg_ctl" -D "$d/db" -o "-p $PGPORT -c listen_addresses=127.0.0.1 -c unix_socket_directories=''" -l "$d/log" -w start >/dev/null
trap '"$p/pg_ctl" -D "$d/db" -m fast -w stop >/dev/null; rm -rf "$d"' EXIT
cli=("$p/psql" -d postgres -qXtA -v ON_ERROR_STOP=1)
"${cli[@]}" -f "$w/../native/privatefour/module_01_configured.sql" -o "$d/r.log" 2>"$d/notices.log"
"${cli[@]}" -f "$w/../native/privatefour/module_02_configured.sql" -o "$d/r.log" 2>>"$d/notices.log"
fields='select account,latest_doai,impact_start_date,impact_end_date,cure_consecutive_months_required,credit_cure_date,manual_review_flag,manual_review_reason from module2.metro2_remediation_final where account=57'
"${cli[@]}" -c "$fields" > "$w/reuse-threshold.out"
"${cli[@]}" -c "SET metro2.reuse_incident_dates='on'" -f "$w/../native/privatefour/module_02_configured.sql" -o "$d/r.log" 2>>"$d/notices.log"
"${cli[@]}" -c "$fields" >> "$w/reuse-threshold.out"
"${cli[@]}" -c "SET metro2.reuse_incident_dates='on'" -f "$w/../source/src/module_02_metro2_remediation_engine.sql" -o "$d/r.log" 2>>"$d/notices.log"
"${cli[@]}" -c "$fields" >> "$w/reuse-threshold.out"
"${cli[@]}" -v expected_accounts=1000 -v required_months=4 -f "$w/../source/tools/verify_study.sql" > "$w/reuse-threshold-original-verify.json"
cat "$w/reuse-threshold.out"

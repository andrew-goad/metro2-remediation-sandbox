"""Challenge the standalone threshold comparator on copies of valid local viewer files."""
from pathlib import Path
import json, subprocess, sys, tempfile
base=Path(__file__).resolve().parents[1]
script=base/'source/tools/compare_study_thresholds.py'
source=base/'native/export1000.js';four=base/'native/exportfour.js'
def run(left,right):
 r=subprocess.run([sys.executable,str(script),str(left),str(right)],capture_output=True,text=True)
 if r.returncode==0:
  j=json.loads(r.stdout);return {'exit':0,'pass':j['pass'],'counts':[j[k]['monthly_cure_reviews'] for k in ('first','second')],'thresholds':[s['cure_months'] for s in j['studies']],'same_configured_hash':j['studies'][0]['module2_configured_sha256']==j['studies'][1]['module2_configured_sha256']}
 return {'exit':r.returncode,'reason':r.stderr.splitlines()[-1]}
report={'intact':run(source,four)}
with tempfile.TemporaryDirectory() as td:
 d=Path(td);fake=d/'f.js'
 real=four.read_text(); lines=real.splitlines(keepends=True);ix=next(i for i,l in enumerate(lines) if l.startswith('{"account":57,'))
 s=lines[ix];assert '"manual_review_flag":1' in s and '"manual_review_reason":"INSUFFICIENT_POST_IMPACT_HISTORY"' in s
 lines[ix]=s.replace('"manual_review_flag":1','"manual_review_flag":0').replace('"manual_review_reason":"INSUFFICIENT_POST_IMPACT_HISTORY"','"manual_review_reason":null')
 fake.write_text(''.join(lines));report['genuine_four_output_changed_57_to_closed']=run(source,fake)
 one=source.read_text()
 assert '"cureMonths":3' in one
 fake.write_text(one.replace('"cure_consecutive_months_required":3','"cure_consecutive_months_required":4'))
 report['copied_three_viewer_falsely_labeled_four_on_rows_only']=run(source,fake)
print(json.dumps(report,indent=2))
